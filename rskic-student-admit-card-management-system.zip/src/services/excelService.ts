import * as XLSX from 'xlsx';
import { Student, StudentClass, ALL_CLASSES, ALL_SECTIONS, Gender } from '../types';

export interface ParsedRowResult {
  rowNumber: number;
  data: Partial<Student>;
  isValid: boolean;
  errors: string[];
}

export const excelService = {
  // Download standard template for school staff
  downloadTemplate() {
    const templateData = [
      {
        'Student Name': 'Rahul Kumar',
        "Father's Name": 'Raj Kumar',
        "Mother's Name": 'Sita Devi',
        'Class': '10',
        'Section': 'A',
        'Roll Number': '101',
        'Date of Birth (YYYY-MM-DD)': '2010-04-15',
        'Gender': 'Male',
        'Admission Number': 'ADM-2022-452',
        'Student ID': 'RSKIC-ST-101',
      },
      {
        'Student Name': 'Priya Singh',
        "Father's Name": 'Ram Singh',
        "Mother's Name": 'Anita Singh',
        'Class': '8',
        'Section': 'A',
        'Roll Number': '102',
        'Date of Birth (YYYY-MM-DD)': '2012-08-20',
        'Gender': 'Female',
        'Admission Number': 'ADM-2023-118',
        'Student ID': 'RSKIC-ST-102',
      },
      {
        'Student Name': 'Amit Sharma',
        "Father's Name": 'Dinesh Sharma',
        "Mother's Name": 'Sunita Sharma',
        'Class': '12',
        'Section': 'B',
        'Roll Number': '103',
        'Date of Birth (YYYY-MM-DD)': '2008-11-05',
        'Gender': 'Male',
        'Admission Number': 'ADM-2020-890',
        'Student ID': 'RSKIC-ST-103',
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);

    // Auto-fit column widths
    const colWidths = [
      { wch: 22 }, // Student Name
      { wch: 22 }, // Father's Name
      { wch: 22 }, // Mother's Name
      { wch: 10 }, // Class
      { wch: 10 }, // Section
      { wch: 14 }, // Roll Number
      { wch: 26 }, // Date of Birth
      { wch: 12 }, // Gender
      { wch: 18 }, // Admission Number
      { wch: 16 }, // Student ID
    ];
    worksheet['!cols'] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Students_Template');
    XLSX.writeFile(workbook, 'RSKIC_Student_Import_Template.xlsx');
  },

  // Parse and validate uploaded Excel / CSV file
  async parseAndValidate(
    file: File,
    existingStudents: Student[]
  ): Promise<{ results: ParsedRowResult[]; validCount: number; errorCount: number }> {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: 'array' });
    const firstSheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[firstSheetName];

    // Read rows as array of objects
    const rows = XLSX.utils.sheet_to_json<Record<string, any>>(sheet, { defval: '' });

    const existingRolls = new Set(existingStudents.map((s) => `${s.class}-${s.rollNumber}`.toLowerCase()));
    const existingStudentIds = new Set(
      existingStudents.filter((s) => s.studentId).map((s) => s.studentId!.toLowerCase())
    );

    const fileRolls = new Set<string>();
    const fileStudentIds = new Set<string>();

    const results: ParsedRowResult[] = [];
    let validCount = 0;
    let errorCount = 0;

    rows.forEach((row, index) => {
      const rowNumber = index + 2; // header is row 1
      const errors: string[] = [];

      // Extract field values accommodating variations in header titles
      const name = String(row['Student Name'] || row['studentName'] || row['Name'] || '').trim();
      const father = String(row["Father's Name"] || row['Father Name'] || row['fatherName'] || '').trim();
      const mother = String(row["Mother's Name"] || row['Mother Name'] || row['motherName'] || '').trim();
      const rawClass = String(row['Class'] || row['class'] || '').trim();
      const rawSection = String(row['Section'] || row['section'] || 'A').trim().toUpperCase();
      const roll = String(row['Roll Number'] || row['Roll No'] || row['rollNumber'] || '').trim();
      const dob = String(row['Date of Birth (YYYY-MM-DD)'] || row['Date of Birth'] || row['DOB'] || row['dob'] || '').trim();
      const rawGender = String(row['Gender'] || row['gender'] || 'Male').trim();
      const admissionNumber = String(row['Admission Number'] || row['Admission No'] || row['admissionNumber'] || '').trim();
      const studentId = String(row['Student ID'] || row['studentId'] || '').trim();

      // Validation 1: Required Name
      if (!name) {
        errors.push('Student Name is required');
      }

      // Validation 2: Required Father Name
      if (!father) {
        errors.push("Father's Name is required");
      }

      // Validation 3: Valid Class
      const matchedClass = ALL_CLASSES.find((c) => c.toLowerCase() === rawClass.toLowerCase());
      if (!matchedClass) {
        errors.push(`Invalid Class "${rawClass}". Allowed: Nursery, LKG, UKG, 1 to 12`);
      }

      // Validation 4: Valid Section
      const matchedSection = ALL_SECTIONS.find((s) => s === rawSection) || 'A';

      // Validation 5: Required Roll Number
      if (!roll) {
        errors.push('Roll Number is required');
      } else if (matchedClass) {
        const classRollKey = `${matchedClass}-${roll}`.toLowerCase();
        if (existingRolls.has(classRollKey)) {
          errors.push(`Roll Number "${roll}" already exists in Class ${matchedClass}`);
        } else if (fileRolls.has(classRollKey)) {
          errors.push(`Duplicate Roll Number "${roll}" in Class ${matchedClass} within this file`);
        } else {
          fileRolls.add(classRollKey);
        }
      }

      // Validation 6: Duplicate Student ID
      if (studentId) {
        const sIdLower = studentId.toLowerCase();
        if (existingStudentIds.has(sIdLower)) {
          errors.push(`Student ID "${studentId}" already exists in the system`);
        } else if (fileStudentIds.has(sIdLower)) {
          errors.push(`Duplicate Student ID "${studentId}" in this file`);
        } else {
          fileStudentIds.add(sIdLower);
        }
      }

      // Normalise gender
      let gender: Gender = 'Male';
      if (/female|f|girl/i.test(rawGender)) gender = 'Female';
      else if (/other|o/i.test(rawGender)) gender = 'Other';

      const isValid = errors.length === 0;
      if (isValid) validCount++;
      else errorCount++;

      results.push({
        rowNumber,
        isValid,
        errors,
        data: {
          studentName: name,
          fatherName: father,
          motherName: mother,
          class: (matchedClass as StudentClass) || '10',
          section: matchedSection,
          rollNumber: roll,
          dob: dob || '2010-01-01',
          gender,
          admissionNumber,
          studentId: studentId || (roll ? `RSKIC-${roll}` : ''),
        },
      });
    });

    return { results, validCount, errorCount };
  },
};
