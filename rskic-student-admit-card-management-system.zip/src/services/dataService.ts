import {
  collection,
  doc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase/config';
import {
  Student,
  Exam,
  TimetableEntry,
  SchoolSettings,
  ActivityLog
} from '../types';
import {
  DEFAULT_SCHOOL_SETTINGS,
  DEFAULT_EXAM,
  DEFAULT_TIMETABLES,
  SAMPLE_STUDENTS
} from '../firebase/defaultData';

const STORAGE_KEYS = {
  STUDENTS: 'rskic_students_cache',
  EXAMS: 'rskic_exams_cache',
  TIMETABLES: 'rskic_timetables_cache',
  SETTINGS: 'rskic_settings_cache',
  LOGS: 'rskic_logs_cache',
};

// Helper for local storage backup
function getCached<T>(key: string, defaultVal: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : defaultVal;
  } catch (e) {
    return defaultVal;
  }
}

function setCached<T>(key: string, val: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {
    console.warn('Storage limit reached for key', key);
  }
}

export const dataService = {
  // ==================== STUDENTS ====================
  async getStudents(): Promise<Student[]> {
    try {
      const snap = await getDocs(collection(db, 'students'));
      if (snap.empty) {
        // Initialize with sample students if totally empty
        const initial = getCached<Student[]>(STORAGE_KEYS.STUDENTS, SAMPLE_STUDENTS);
        for (const s of initial) {
          await this.saveStudent(s);
        }
        return initial;
      }
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Student));
      setCached(STORAGE_KEYS.STUDENTS, list);
      return list;
    } catch (err) {
      console.warn('Firestore getStudents failed, falling back to cache:', err);
      return getCached<Student[]>(STORAGE_KEYS.STUDENTS, SAMPLE_STUDENTS);
    }
  },

  async saveStudent(student: Student): Promise<void> {
    try {
      const studentId = student.id || `stud-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const payload = {
        ...student,
        id: studentId,
        updatedAt: new Date().toISOString(),
      };
      await setDoc(doc(db, 'students', studentId), payload, { merge: true });

      // Update cache
      const cached = getCached<Student[]>(STORAGE_KEYS.STUDENTS, SAMPLE_STUDENTS);
      const idx = cached.findIndex((s) => s.id === studentId);
      if (idx >= 0) {
        cached[idx] = payload;
      } else {
        cached.push(payload);
      }
      setCached(STORAGE_KEYS.STUDENTS, cached);
    } catch (err) {
      console.warn('saveStudent firestore error, saved to local cache:', err);
      // Still update local cache for resiliency
      const cached = getCached<Student[]>(STORAGE_KEYS.STUDENTS, SAMPLE_STUDENTS);
      const idx = cached.findIndex((s) => s.id === student.id);
      if (idx >= 0) cached[idx] = student;
      else cached.push(student);
      setCached(STORAGE_KEYS.STUDENTS, cached);
    }
  },

  async deleteStudent(studentId: string): Promise<void> {
    try {
      await deleteDoc(doc(db, 'students', studentId));
      const cached = getCached<Student[]>(STORAGE_KEYS.STUDENTS, SAMPLE_STUDENTS);
      const filtered = cached.filter((s) => s.id !== studentId);
      setCached(STORAGE_KEYS.STUDENTS, filtered);
    } catch (err) {
      console.warn('deleteStudent firestore error:', err);
      const cached = getCached<Student[]>(STORAGE_KEYS.STUDENTS, SAMPLE_STUDENTS);
      setCached(STORAGE_KEYS.STUDENTS, cached.filter((s) => s.id !== studentId));
    }
  },

  async bulkSaveStudents(students: Student[]): Promise<number> {
    let successCount = 0;
    const cached = getCached<Student[]>(STORAGE_KEYS.STUDENTS, SAMPLE_STUDENTS);

    for (const student of students) {
      try {
        const studentId = student.id || `stud-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
        const record = { ...student, id: studentId, updatedAt: new Date().toISOString() };
        await setDoc(doc(db, 'students', studentId), record, { merge: true });
        
        const idx = cached.findIndex((s) => s.id === studentId);
        if (idx >= 0) cached[idx] = record;
        else cached.push(record);
        successCount++;
      } catch (err) {
        // Fallback for this student
        const idx = cached.findIndex((s) => s.id === student.id);
        if (idx >= 0) cached[idx] = student;
        else cached.push(student);
        successCount++;
      }
    }

    setCached(STORAGE_KEYS.STUDENTS, cached);
    return successCount;
  },

  generateNextAdmitCardNumber(existingStudents: Student[]): string {
    const year = new Date().getFullYear();
    const prefix = `RSKIC-${year}-`;
    let highest = 0;

    for (const s of existingStudents) {
      if (s.admitCardNumber && s.admitCardNumber.startsWith(prefix)) {
        const numPart = parseInt(s.admitCardNumber.replace(prefix, ''), 10);
        if (!isNaN(numPart) && numPart > highest) {
          highest = numPart;
        }
      }
    }
    const nextNum = highest + 1;
    return `${prefix}${String(nextNum).padStart(4, '0')}`;
  },

  // ==================== EXAMS ====================
  async getExams(): Promise<Exam[]> {
    try {
      const snap = await getDocs(collection(db, 'exams'));
      if (snap.empty) {
        await this.saveExam(DEFAULT_EXAM);
        return [DEFAULT_EXAM];
      }
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Exam));
      setCached(STORAGE_KEYS.EXAMS, list);
      return list;
    } catch (err) {
      console.warn('getExams firestore fallback:', err);
      return getCached<Exam[]>(STORAGE_KEYS.EXAMS, [DEFAULT_EXAM]);
    }
  },

  async saveExam(exam: Exam): Promise<void> {
    try {
      const examId = exam.id || `exam-${Date.now()}`;
      const payload = { ...exam, id: examId, updatedAt: new Date().toISOString() };
      await setDoc(doc(db, 'exams', examId), payload, { merge: true });

      const cached = getCached<Exam[]>(STORAGE_KEYS.EXAMS, [DEFAULT_EXAM]);
      const idx = cached.findIndex((e) => e.id === examId);
      if (idx >= 0) cached[idx] = payload;
      else cached.push(payload);
      setCached(STORAGE_KEYS.EXAMS, cached);
    } catch (err) {
      console.warn('saveExam fallback:', err);
      const cached = getCached<Exam[]>(STORAGE_KEYS.EXAMS, [DEFAULT_EXAM]);
      const idx = cached.findIndex((e) => e.id === exam.id);
      if (idx >= 0) cached[idx] = exam;
      else cached.push(exam);
      setCached(STORAGE_KEYS.EXAMS, cached);
    }
  },

  async deleteExam(examId: string): Promise<void> {
    try {
      await deleteDoc(doc(db, 'exams', examId));
    } catch (err) {
      console.warn('deleteExam error:', err);
    }
    const cached = getCached<Exam[]>(STORAGE_KEYS.EXAMS, [DEFAULT_EXAM]);
    setCached(STORAGE_KEYS.EXAMS, cached.filter((e) => e.id !== examId));
  },

  // ==================== TIMETABLES ====================
  async getTimetables(): Promise<TimetableEntry[]> {
    try {
      const snap = await getDocs(collection(db, 'timetables'));
      if (snap.empty) {
        // Initialize with default schedule from school photo
        for (const t of DEFAULT_TIMETABLES) {
          await this.saveTimetableEntry(t);
        }
        return DEFAULT_TIMETABLES;
      }
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as TimetableEntry));
      setCached(STORAGE_KEYS.TIMETABLES, list);
      return list;
    } catch (err) {
      console.warn('getTimetables firestore fallback:', err);
      return getCached<TimetableEntry[]>(STORAGE_KEYS.TIMETABLES, DEFAULT_TIMETABLES);
    }
  },

  async saveTimetableEntry(entry: TimetableEntry): Promise<void> {
    try {
      const entryId = entry.id || `tt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const payload = { ...entry, id: entryId };
      await setDoc(doc(db, 'timetables', entryId), payload, { merge: true });

      const cached = getCached<TimetableEntry[]>(STORAGE_KEYS.TIMETABLES, DEFAULT_TIMETABLES);
      const idx = cached.findIndex((t) => t.id === entryId);
      if (idx >= 0) cached[idx] = payload;
      else cached.push(payload);
      setCached(STORAGE_KEYS.TIMETABLES, cached);
    } catch (err) {
      console.warn('saveTimetableEntry fallback:', err);
      const cached = getCached<TimetableEntry[]>(STORAGE_KEYS.TIMETABLES, DEFAULT_TIMETABLES);
      const idx = cached.findIndex((t) => t.id === entry.id);
      if (idx >= 0) cached[idx] = entry;
      else cached.push(entry);
      setCached(STORAGE_KEYS.TIMETABLES, cached);
    }
  },

  async deleteTimetableEntry(entryId: string): Promise<void> {
    try {
      await deleteDoc(doc(db, 'timetables', entryId));
    } catch (err) {
      console.warn('deleteTimetableEntry fallback:', err);
    }
    const cached = getCached<TimetableEntry[]>(STORAGE_KEYS.TIMETABLES, DEFAULT_TIMETABLES);
    setCached(STORAGE_KEYS.TIMETABLES, cached.filter((t) => t.id !== entryId));
  },

  // ==================== SCHOOL SETTINGS ====================
  async getSchoolSettings(): Promise<SchoolSettings> {
    try {
      const snap = await getDocs(collection(db, 'schoolSettings'));
      if (snap.empty) {
        await this.saveSchoolSettings(DEFAULT_SCHOOL_SETTINGS);
        return DEFAULT_SCHOOL_SETTINGS;
      }
      const docData = snap.docs[0].data() as SchoolSettings;
      const settings = { ...DEFAULT_SCHOOL_SETTINGS, ...docData, id: snap.docs[0].id };
      setCached(STORAGE_KEYS.SETTINGS, settings);
      return settings;
    } catch (err) {
      console.warn('getSchoolSettings fallback:', err);
      return getCached<SchoolSettings>(STORAGE_KEYS.SETTINGS, DEFAULT_SCHOOL_SETTINGS);
    }
  },

  async saveSchoolSettings(settings: SchoolSettings): Promise<void> {
    try {
      const settingId = settings.id || 'default';
      const payload = { ...settings, id: settingId, updatedAt: new Date().toISOString() };
      await setDoc(doc(db, 'schoolSettings', settingId), payload, { merge: true });
      setCached(STORAGE_KEYS.SETTINGS, payload);
    } catch (err) {
      console.warn('saveSchoolSettings fallback:', err);
      setCached(STORAGE_KEYS.SETTINGS, settings);
    }
  },

  // ==================== ACTIVITY LOGS ====================
  async getActivityLogs(): Promise<ActivityLog[]> {
    try {
      const q = query(collection(db, 'activityLogs'), orderBy('timestamp', 'desc'));
      const snap = await getDocs(q);
      if (snap.empty) {
        return getCached<ActivityLog[]>(STORAGE_KEYS.LOGS, [
          {
            id: 'log-1',
            message: 'Half Yearly Examination 2026-27 schedule loaded',
            type: 'exam',
            timestamp: new Date().toISOString(),
          },
          {
            id: 'log-2',
            message: 'School settings initialized for RSKIC Bamdera Balpur Gonda',
            type: 'settings',
            timestamp: new Date(Date.now() - 3600000).toISOString(),
          },
          {
            id: 'log-3',
            message: 'Sample students added for quick demonstration',
            type: 'student',
            timestamp: new Date(Date.now() - 7200000).toISOString(),
          }
        ]);
      }
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as ActivityLog));
      setCached(STORAGE_KEYS.LOGS, list);
      return list;
    } catch (err) {
      return getCached<ActivityLog[]>(STORAGE_KEYS.LOGS, []);
    }
  },

  async logActivity(message: string, type: ActivityLog['type'], userEmail?: string): Promise<void> {
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      message,
      type,
      timestamp: new Date().toISOString(),
      userEmail,
    };
    try {
      await setDoc(doc(db, 'activityLogs', newLog.id), newLog);
    } catch (err) {
      // ignore
    }
    const cached = getCached<ActivityLog[]>(STORAGE_KEYS.LOGS, []);
    const updated = [newLog, ...cached].slice(0, 50);
    setCached(STORAGE_KEYS.LOGS, updated);
  }
};
