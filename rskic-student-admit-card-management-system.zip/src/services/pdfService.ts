import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export const pdfService = {
  // Generate single student admit card PDF from HTML container
  async generateSingleAdmitCardPdf(
    element: HTMLElement,
    filename: string
  ): Promise<void> {
    try {
      const canvas = await html2canvas(element, {
        scale: 2.5, // High resolution for clear Hindi text and crisp borders
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = 210;
      const pdfHeight = 297;
      const margin = 8;
      const contentWidth = pdfWidth - margin * 2;
      const contentHeight = (canvas.height * contentWidth) / canvas.width;

      pdf.addImage(
        imgData,
        'JPEG',
        margin,
        margin,
        contentWidth,
        Math.min(contentHeight, pdfHeight - margin * 2)
      );

      pdf.save(filename);
    } catch (error) {
      console.error('Error generating single admit card PDF:', error);
      throw error;
    }
  },

  // Generate bulk multi-page PDF from a list of HTML elements
  async generateBulkAdmitCardsPdf(
    elements: HTMLElement[],
    filename: string,
    onProgress?: (current: number, total: number) => void
  ): Promise<void> {
    try {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = 210;
      const pdfHeight = 297;
      const margin = 8;
      const contentWidth = pdfWidth - margin * 2;

      for (let i = 0; i < elements.length; i++) {
        if (onProgress) {
          onProgress(i + 1, elements.length);
        }

        const el = elements[i];
        const canvas = await html2canvas(el, {
          scale: 2.2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff',
          logging: false,
        });

        const imgData = canvas.toDataURL('image/jpeg', 0.92);
        const contentHeight = (canvas.height * contentWidth) / canvas.width;

        if (i > 0) {
          pdf.addPage('a4', 'portrait');
        }

        pdf.addImage(
          imgData,
          'JPEG',
          margin,
          margin,
          contentWidth,
          Math.min(contentHeight, pdfHeight - margin * 2)
        );
      }

      pdf.save(filename);
    } catch (error) {
      console.error('Bulk admit card PDF generation failed:', error);
      throw error;
    }
  },

  // Print directly using browser print engine with A4 CSS page setup
  printElement(elementId: string = 'printable-admit-card') {
    const printEl = document.getElementById(elementId);
    if (!printEl) {
      window.print();
      return;
    }
    window.print();
  },
};
