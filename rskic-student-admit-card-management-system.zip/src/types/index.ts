export type StudentClass =
  | 'Nursery'
  | 'LKG'
  | 'UKG'
  | '1'
  | '2'
  | '3'
  | '4'
  | '5'
  | '6'
  | '7'
  | '8'
  | '9'
  | '10'
  | '11'
  | '12';

export const ALL_CLASSES: StudentClass[] = [
  'Nursery',
  'LKG',
  'UKG',
  '1',
  '2',
  '3',
  '4',
  '5',
  '6',
  '7',
  '8',
  '9',
  '10',
  '11',
  '12',
];

export type Section = 'A' | 'B' | 'C' | 'D' | 'E';
export const ALL_SECTIONS: Section[] = ['A', 'B', 'C', 'D', 'E'];

export type Gender = 'Male' | 'Female' | 'Other';

export interface Student {
  id: string;
  studentName: string;
  fatherName: string;
  motherName?: string;
  class: StudentClass;
  section: Section;
  rollNumber: string;
  dob: string;
  gender: Gender;
  photoUrl?: string;
  admissionNumber?: string;
  studentId?: string;
  admitCardNumber: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Exam {
  id: string;
  examName: string;
  session: string;
  centre: string;
  startDate: string;
  endDate: string;
  defaultExamTime: string;
  reportingTime: string;
  instructions?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface TimetableEntry {
  id: string;
  examId: string;
  date: string; // DD/MM/YYYY or YYYY-MM-DD
  class: StudentClass;
  subject: string;
  examTime: string;
  reportingTime: string;
  roomCentre?: string;
  remarks?: string;
}

export interface SchoolSettings {
  id: string;
  schoolName: string;
  hindiSchoolName?: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  principalName: string;
  principalSignature?: string;
  classTeacherSignature?: string;
  schoolStamp?: string;
  logoUrl?: string;
  instructions: string[];
  updatedAt?: string;
}

export interface ActivityLog {
  id: string;
  message: string;
  type: 'admit_card' | 'student' | 'exam' | 'timetable' | 'settings' | 'import';
  timestamp: string;
  userEmail?: string;
}

export interface AdminUser {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  role: 'admin' | 'superadmin';
}
