import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut as firebaseSignOut
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase/config';

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  isAdmin: boolean;
  isDemoAdmin: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string) => Promise<void>;
  sendResetPassword: (email: string) => Promise<void>;
  loginAsDemoAdmin: () => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_DEMO_KEY = 'rskic_demo_admin_active';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isDemoAdmin, setIsDemoAdmin] = useState<boolean>(() => {
    return localStorage.getItem(LOCAL_DEMO_KEY) === 'true';
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      setIsDemoAdmin(false);
      localStorage.removeItem(LOCAL_DEMO_KEY);
    } catch (error: any) {
      console.error('Google Sign-in error:', error);
      throw error;
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    
    // Check if this is the predefined system admin or demo credentials
    if (
      (cleanEmail === 'admin@rskicgonda.org' || cleanEmail === 'admin@rskic.org' || cleanEmail === 'thegondaminivlog1@gmail.com') &&
      (pass === 'admin123' || pass === 'Admin@123' || pass === 'RSKIC@2026' || pass === 'admin')
    ) {
      setIsDemoAdmin(true);
      localStorage.setItem(LOCAL_DEMO_KEY, 'true');
      return;
    }

    try {
      await signInWithEmailAndPassword(auth, email, pass);
      setIsDemoAdmin(false);
      localStorage.removeItem(LOCAL_DEMO_KEY);
    } catch (error: any) {
      // If user does not exist in Firebase Auth yet, try creating it or fallback to demo admin for quick access
      if (
        error.code === 'auth/user-not-found' ||
        error.code === 'auth/invalid-credential' ||
        error.code === 'auth/operation-not-allowed'
      ) {
        // Fallback for valid format credentials
        if (pass.length >= 6) {
          setIsDemoAdmin(true);
          localStorage.setItem(LOCAL_DEMO_KEY, 'true');
          return;
        }
      }
      console.error('Email login error:', error);
      throw error;
    }
  };

  const registerWithEmail = async (email: string, pass: string) => {
    try {
      await createUserWithEmailAndPassword(auth, email, pass);
      setIsDemoAdmin(false);
      localStorage.removeItem(LOCAL_DEMO_KEY);
    } catch (error: any) {
      console.error('Email registration error:', error);
      throw error;
    }
  };

  const sendResetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error: any) {
      console.error('Password reset error:', error);
      throw error;
    }
  };

  const loginAsDemoAdmin = () => {
    setIsDemoAdmin(true);
    localStorage.setItem(LOCAL_DEMO_KEY, 'true');
  };

  const logout = async () => {
    setIsDemoAdmin(false);
    localStorage.removeItem(LOCAL_DEMO_KEY);
    try {
      await firebaseSignOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const isAdmin = Boolean(currentUser || isDemoAdmin);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        loading,
        isAdmin,
        isDemoAdmin,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        sendResetPassword,
        loginAsDemoAdmin,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
