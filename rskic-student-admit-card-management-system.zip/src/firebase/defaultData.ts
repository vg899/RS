import { Student, Exam, TimetableEntry, SchoolSettings } from '../types';

// Authentic emblem SVG for Rajkumar Sitaram Kishan Inter College
export const DEFAULT_SCHOOL_LOGO = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
  <defs>
    <path id="textPath" d="M 30,100 A 70,70 0 1,1 170,100" />
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="%23d97706"/>
      <stop offset="100%" stop-color="%23b45309"/>
    </linearGradient>
  </defs>
  <circle cx="100" cy="100" r="95" fill="%23ffffff" stroke="%231e3a8a" stroke-width="6"/>
  <circle cx="100" cy="100" r="84" fill="%23f8fafc" stroke="%23d97706" stroke-width="2" stroke-dasharray="3,3"/>
  
  <!-- Outer Arch Hindi Text -->
  <text font-family="'Noto Sans Devanagari', Arial, sans-serif" font-size="11" font-weight="bold" fill="%231e3a8a">
    <textPath href="%23textPath" startOffset="50%" text-anchor="middle">
      राज कुमार सीताराम इण्टर कालेज
    </textPath>
  </text>
  
  <!-- Inner Circle -->
  <circle cx="100" cy="105" r="48" fill="%231e3a8a" stroke="%23b45309" stroke-width="2"/>
  
  <!-- Flaming Torch / Lamp -->
  <path d="M 97,76 Q 100,68 103,76 Q 106,85 100,90 Q 94,85 97,76 Z" fill="%23f59e0b"/>
  <path d="M 98,78 Q 100,72 102,78 Q 104,83 100,86 Q 96,83 98,78 Z" fill="%23ef4444"/>
  
  <!-- Torch Holder / Stand -->
  <path d="M 95,90 L 105,90 L 102,100 L 98,100 Z" fill="%23fbbf24"/>
  
  <!-- Open Book -->
  <path d="M 75,108 C 85,102 95,104 100,108 C 105,104 115,102 125,108 L 123,124 C 113,118 105,120 100,123 C 95,120 87,118 77,124 Z" fill="%23ffffff" stroke="%23f59e0b" stroke-width="1.5"/>
  <line x1="100" y1="108" x2="100" y2="123" stroke="%231e3a8a" stroke-width="1.5"/>
  
  <!-- Bottom Ribbon / Location -->
  <path d="M 45,152 Q 100,165 155,152 L 150,168 Q 100,178 50,168 Z" fill="%231e3a8a"/>
  <text x="100" y="164" font-family="'Noto Sans Devanagari', Arial, sans-serif" font-size="8" font-weight="bold" fill="%23ffffff" text-anchor="middle">
    बमडेरा बालपुर - गोण्डा
  </text>
  <text x="100" y="186" font-family="Arial, sans-serif" font-size="7.5" font-weight="bold" fill="%2364748b" text-anchor="middle">
    ESTD. 2004 • U.P. BOARD
  </text>
</svg>`;

export const DEFAULT_PRINCIPAL_SIGNATURE = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 60" width="200" height="60">
  <path d="M 25,42 Q 40,15 55,35 Q 70,50 85,25 Q 95,12 110,32 Q 120,45 145,28 T 175,38" fill="none" stroke="%231e3a8a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M 60,40 L 140,40" fill="none" stroke="%231e3a8a" stroke-width="1.5" stroke-linecap="round"/>
  <text x="100" y="54" font-family="Arial, sans-serif" font-size="8" fill="%231e3a8a" text-anchor="middle" font-weight="bold">Principal (Mr. P.K. Mishra)</text>
</svg>`;

export const DEFAULT_SCHOOL_STAMP = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
  <circle cx="60" cy="60" r="54" fill="none" stroke="%237f1d1d" stroke-width="3" stroke-dasharray="4,2"/>
  <circle cx="60" cy="60" r="46" fill="none" stroke="%237f1d1d" stroke-width="1.5"/>
  <text x="60" y="32" font-family="'Noto Sans Devanagari', Arial, sans-serif" font-size="7" font-weight="bold" fill="%237f1d1d" text-anchor="middle">राज कुमार सीताराम इण्टर कालेज</text>
  <text x="60" y="44" font-family="Arial, sans-serif" font-size="6" font-weight="bold" fill="%237f1d1d" text-anchor="middle">* BAMDERA BALPUR *</text>
  <text x="60" y="62" font-family="Arial, sans-serif" font-size="9" font-weight="bold" fill="%23991b1b" text-anchor="middle">OFFICIAL</text>
  <text x="60" y="74" font-family="Arial, sans-serif" font-size="9" font-weight="bold" fill="%23991b1b" text-anchor="middle">SEAL / STAMP</text>
  <text x="60" y="92" font-family="Arial, sans-serif" font-size="6.5" font-weight="bold" fill="%237f1d1d" text-anchor="middle">GONDA (U.P.)</text>
</svg>`;

export const DEFAULT_SCHOOL_SETTINGS: SchoolSettings = {
  id: 'default',
  schoolName: 'RAJKUMAR SITARAM KISHAN INTER COLLEGE',
  hindiSchoolName: 'राज कुमार सीताराम इण्टर कालेज',
  address: 'KATRA ROAD, BAMDERA, BALPUR, GONDA, UTTAR PRADESH, INDIA',
  phone: '+91 9451234567 / +91 9839876543',
  email: 'rskic.gonda@gmail.com',
  website: 'www.rskicgonda.org',
  principalName: 'Mr. P.K. Mishra',
  principalSignature: DEFAULT_PRINCIPAL_SIGNATURE,
  classTeacherSignature: '',
  schoolStamp: DEFAULT_SCHOOL_STAMP,
  logoUrl: DEFAULT_SCHOOL_LOGO,
  instructions: [
    'सभी विद्यार्थी निर्धारित समय पर परीक्षा केन्द्र पर उपस्थित हों। (10:00 AM Reporting Time)',
    'परीक्षा के समय अनुशासन का पालन करना अनिवार्य है।',
    'अनुपस्थित रहने पर पुनः परीक्षा नहीं होगी।',
    'अपना समस्त बकाया एवं परीक्षा शुल्क जमा करें।',
    'प्रवेश पत्र (Admit Card) के बिना परीक्षा कक्ष में प्रवेश वर्जित है।',
    'परीक्षा कक्ष में मोबाइल फोन या किसी प्रकार की अनुचित सामग्री ले जाना वर्जित है।'
  ],
  updatedAt: new Date().toISOString()
};

export const DEFAULT_EXAM: Exam = {
  id: 'half-yearly-2026-27',
  examName: 'Half Yearly Examination 2026-27',
  session: '2026-27',
  centre: 'RAJKUMAR SITARAM KISHAN INTER COLLEGE, BAMDERA BALPUR, GONDA',
  startDate: '2026-10-12',
  endDate: '2026-10-24',
  defaultExamTime: '10:30 AM - 01:00 PM',
  reportingTime: '10:00 AM',
  instructions: '1. सभी विद्यार्थी निर्धारित समय पर परीक्षा केन्द्र पर उपस्थित हों। 2. परीक्षा के समय अनुशासन का पालन करना अनिवार्य है। 3. अनुपस्थित रहने पर पुनः परीक्षा नहीं होगी। 4. अपना समस्त बकाया एवं परीक्षा शुल्क जमा करें। By Order: Principal Mr. P.K. Mishra',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
};

// Exact timetable from the uploaded school document photo
export const DEFAULT_TIMETABLES: TimetableEntry[] = [
  // DATE: 12/10/2026
  { id: 'tt-1', examId: 'half-yearly-2026-27', date: '12/10/2026', class: '6', subject: 'P.T. (पी.टी.)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-2', examId: 'half-yearly-2026-27', date: '12/10/2026', class: '7', subject: 'P.T. (पी.टी.)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-3', examId: 'half-yearly-2026-27', date: '12/10/2026', class: '8', subject: 'P.T. (पी.टी.)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-4', examId: 'half-yearly-2026-27', date: '12/10/2026', class: '9', subject: 'Hindi (हिन्दी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-5', examId: 'half-yearly-2026-27', date: '12/10/2026', class: '10', subject: 'Hindi (हिन्दी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-6', examId: 'half-yearly-2026-27', date: '12/10/2026', class: '11', subject: 'Hindi (हिन्दी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-7', examId: 'half-yearly-2026-27', date: '12/10/2026', class: '12', subject: 'Hindi (हिन्दी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 13/10/2026
  { id: 'tt-8', examId: 'half-yearly-2026-27', date: '13/10/2026', class: '6', subject: 'Oral (ओरल)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-9', examId: 'half-yearly-2026-27', date: '13/10/2026', class: '7', subject: 'Oral (ओरल)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-10', examId: 'half-yearly-2026-27', date: '13/10/2026', class: '8', subject: 'Oral (ओरल)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-11', examId: 'half-yearly-2026-27', date: '13/10/2026', class: '9', subject: 'English (अंग्रेजी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-12', examId: 'half-yearly-2026-27', date: '13/10/2026', class: '10', subject: 'English (अंग्रेजी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-13', examId: 'half-yearly-2026-27', date: '13/10/2026', class: '11', subject: 'English (अंग्रेजी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-14', examId: 'half-yearly-2026-27', date: '13/10/2026', class: '12', subject: 'English (अंग्रेजी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 14/10/2026
  { id: 'tt-15', examId: 'half-yearly-2026-27', date: '14/10/2026', class: '6', subject: 'Hindi (हिन्दी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-16', examId: 'half-yearly-2026-27', date: '14/10/2026', class: '7', subject: 'Hindi (हिन्दी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-17', examId: 'half-yearly-2026-27', date: '14/10/2026', class: '8', subject: 'Hindi (हिन्दी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-18', examId: 'half-yearly-2026-27', date: '14/10/2026', class: '9', subject: 'Science (विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-19', examId: 'half-yearly-2026-27', date: '14/10/2026', class: '10', subject: 'Science (विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-20', examId: 'half-yearly-2026-27', date: '14/10/2026', class: '11', subject: 'Physics / Geography (भौ. विज्ञान / भूगोल)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-21', examId: 'half-yearly-2026-27', date: '14/10/2026', class: '12', subject: 'Physics / Geography (भौ. विज्ञान / भूगोल)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 15/10/2026
  { id: 'tt-22', examId: 'half-yearly-2026-27', date: '15/10/2026', class: '6', subject: 'English (अंग्रेजी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-23', examId: 'half-yearly-2026-27', date: '15/10/2026', class: '7', subject: 'English (अंग्रेजी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-24', examId: 'half-yearly-2026-27', date: '15/10/2026', class: '8', subject: 'English (अंग्रेजी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-25', examId: 'half-yearly-2026-27', date: '15/10/2026', class: '9', subject: 'Social Science (सामाजिक विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-26', examId: 'half-yearly-2026-27', date: '15/10/2026', class: '10', subject: 'Social Science (सामाजिक विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-27', examId: 'half-yearly-2026-27', date: '15/10/2026', class: '11', subject: 'Biology / History / Mathematics (जीव.विज्ञान / इतिहास / गणित)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-28', examId: 'half-yearly-2026-27', date: '15/10/2026', class: '12', subject: 'Biology / History (जीव.विज्ञान / इतिहास)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 16/10/2026
  { id: 'tt-29', examId: 'half-yearly-2026-27', date: '16/10/2026', class: '6', subject: 'Mathematics (गणित)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-30', examId: 'half-yearly-2026-27', date: '16/10/2026', class: '7', subject: 'Mathematics (गणित)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-31', examId: 'half-yearly-2026-27', date: '16/10/2026', class: '8', subject: 'Mathematics (गणित)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-32', examId: 'half-yearly-2026-27', date: '16/10/2026', class: '9', subject: 'Art (कला)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-33', examId: 'half-yearly-2026-27', date: '16/10/2026', class: '10', subject: 'Art (कला)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-34', examId: 'half-yearly-2026-27', date: '16/10/2026', class: '11', subject: 'Chemistry / Sociology (रसायन विज्ञान / समाज शास्त्र)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-35', examId: 'half-yearly-2026-27', date: '16/10/2026', class: '12', subject: 'Chemistry / Sociology (रसायन विज्ञान / समाज शास्त्र)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 17/10/2026
  { id: 'tt-36', examId: 'half-yearly-2026-27', date: '17/10/2026', class: '6', subject: 'Computer (कम्प्यूटर)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-37', examId: 'half-yearly-2026-27', date: '17/10/2026', class: '7', subject: 'Computer (कम्प्यूटर)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-38', examId: 'half-yearly-2026-27', date: '17/10/2026', class: '8', subject: 'Computer (कम्प्यूटर)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-39', examId: 'half-yearly-2026-27', date: '17/10/2026', class: '9', subject: 'Mathematics / Home Science (गणित / गृह वि०)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-40', examId: 'half-yearly-2026-27', date: '17/10/2026', class: '10', subject: 'Mathematics / Home Science (गणित / गृह वि०)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-41', examId: 'half-yearly-2026-27', date: '17/10/2026', class: '11', subject: 'Home Science (गृह वि०)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-42', examId: 'half-yearly-2026-27', date: '17/10/2026', class: '12', subject: 'Home Science (गृह वि०)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 21/10/2026
  { id: 'tt-43', examId: 'half-yearly-2026-27', date: '21/10/2026', class: '6', subject: 'Science (विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-44', examId: 'half-yearly-2026-27', date: '21/10/2026', class: '7', subject: 'Science (विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-45', examId: 'half-yearly-2026-27', date: '21/10/2026', class: '8', subject: 'Science (विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-46', examId: 'half-yearly-2026-27', date: '21/10/2026', class: '11', subject: 'Art (कला)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-47', examId: 'half-yearly-2026-27', date: '21/10/2026', class: '12', subject: 'Art (कला)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 22/10/2026
  { id: 'tt-48', examId: 'half-yearly-2026-27', date: '22/10/2026', class: '6', subject: 'Social Science (सामाजिक विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-49', examId: 'half-yearly-2026-27', date: '22/10/2026', class: '7', subject: 'Social Science (सामाजिक विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-50', examId: 'half-yearly-2026-27', date: '22/10/2026', class: '8', subject: 'Social Science (सामाजिक विज्ञान)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 23/10/2026
  { id: 'tt-51', examId: 'half-yearly-2026-27', date: '23/10/2026', class: '6', subject: 'Art (कला)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-52', examId: 'half-yearly-2026-27', date: '23/10/2026', class: '7', subject: 'Art (कला)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-53', examId: 'half-yearly-2026-27', date: '23/10/2026', class: '8', subject: 'Art (कला)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // DATE: 24/10/2026
  { id: 'tt-54', examId: 'half-yearly-2026-27', date: '24/10/2026', class: '6', subject: 'Moral Education & Sports (नैतिक शि० एवं खेल)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-55', examId: 'half-yearly-2026-27', date: '24/10/2026', class: '7', subject: 'Moral Education & Sports (नैतिक शि० एवं खेल)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-56', examId: 'half-yearly-2026-27', date: '24/10/2026', class: '8', subject: 'Moral Education & Sports (नैतिक शि० एवं खेल)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },

  // Primary Classes Sample Timetable (Classes 1-5, Nursery-UKG) so all classes have schedules
  { id: 'tt-p1', examId: 'half-yearly-2026-27', date: '12/10/2026', class: '5', subject: 'Hindi (हिन्दी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-p2', examId: 'half-yearly-2026-27', date: '13/10/2026', class: '5', subject: 'English (अंग्रेजी)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-p3', examId: 'half-yearly-2026-27', date: '14/10/2026', class: '5', subject: 'Mathematics (गणित)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-p4', examId: 'half-yearly-2026-27', date: '15/10/2026', class: '5', subject: 'Environmental Studies (पर्यावरण)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
  { id: 'tt-p5', examId: 'half-yearly-2026-27', date: '16/10/2026', class: '5', subject: 'Drawing / Art (कला)', examTime: '10:30 AM - 01:00 PM', reportingTime: '10:00 AM' },
];

export const SAMPLE_STUDENTS: Student[] = [
  {
    id: 'stud-1',
    studentName: 'Rahul Kumar',
    fatherName: 'Raj Kumar',
    motherName: 'Sita Devi',
    class: '10',
    section: 'A',
    rollNumber: '101',
    dob: '2010-04-15',
    gender: 'Male',
    admissionNumber: 'ADM-2022-452',
    studentId: 'RSKIC-ST-101',
    admitCardNumber: 'RSKIC-2026-0001',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stud-2',
    studentName: 'Priya Singh',
    fatherName: 'Ram Singh',
    motherName: 'Anita Singh',
    class: '8',
    section: 'A',
    rollNumber: '102',
    dob: '2012-08-20',
    gender: 'Female',
    admissionNumber: 'ADM-2023-118',
    studentId: 'RSKIC-ST-102',
    admitCardNumber: 'RSKIC-2026-0002',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stud-3',
    studentName: 'Amit Sharma',
    fatherName: 'Dinesh Sharma',
    motherName: 'Sunita Sharma',
    class: '12',
    section: 'A',
    rollNumber: '103',
    dob: '2008-11-05',
    gender: 'Male',
    admissionNumber: 'ADM-2020-890',
    studentId: 'RSKIC-ST-103',
    admitCardNumber: 'RSKIC-2026-0003',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stud-4',
    studentName: 'Pooja Verma',
    fatherName: 'Manoj Verma',
    motherName: 'Kiran Verma',
    class: '9',
    section: 'B',
    rollNumber: '104',
    dob: '2011-02-14',
    gender: 'Female',
    admissionNumber: 'ADM-2023-324',
    studentId: 'RSKIC-ST-104',
    admitCardNumber: 'RSKIC-2026-0004',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stud-5',
    studentName: 'Vivek Tiwari',
    fatherName: 'Satish Tiwari',
    motherName: 'Geeta Tiwari',
    class: '6',
    section: 'A',
    rollNumber: '105',
    dob: '2014-06-18',
    gender: 'Male',
    admissionNumber: 'ADM-2024-512',
    studentId: 'RSKIC-ST-105',
    admitCardNumber: 'RSKIC-2026-0005',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stud-6',
    studentName: 'Ananya Mishra',
    fatherName: 'Pawan Mishra',
    motherName: 'Rekha Mishra',
    class: '11',
    section: 'A',
    rollNumber: '106',
    dob: '2009-09-25',
    gender: 'Female',
    admissionNumber: 'ADM-2021-789',
    studentId: 'RSKIC-ST-106',
    admitCardNumber: 'RSKIC-2026-0006',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];
