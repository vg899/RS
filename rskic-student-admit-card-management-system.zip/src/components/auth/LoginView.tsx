import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { DEFAULT_SCHOOL_LOGO } from '../../firebase/defaultData';
import { ShieldCheck, Mail, Lock, LogIn, Key, AlertCircle, ArrowRight, CheckCircle2 } from 'lucide-react';

export const LoginView: React.FC = () => {
  const { loginWithGoogle, loginWithEmail, sendResetPassword, loginAsDemoAdmin } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [resetSent, setResetSent] = useState(false);
  const [showForgot, setShowForgot] = useState(false);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!email.trim() || !password.trim()) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    try {
      setLoading(true);
      await loginWithEmail(email.trim(), password);
    } catch (err: any) {
      setErrorMsg(err.message || 'Invalid credentials or user not found.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setErrorMsg('');
    try {
      setLoading(true);
      await loginWithGoogle();
    } catch (err: any) {
      setErrorMsg(err.message || 'Google sign-in was closed or failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMsg('Please enter your email address to receive reset instructions.');
      return;
    }
    try {
      setLoading(true);
      await sendResetPassword(email.trim());
      setResetSent(true);
      setErrorMsg('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Could not send reset email.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        
        {/* Top Header Card */}
        <div className="bg-blue-950 text-white p-6 text-center border-b border-blue-900">
          <div className="w-20 h-20 mx-auto mb-3 bg-white rounded-full p-1.5 shadow-md flex items-center justify-center">
            <img src={DEFAULT_SCHOOL_LOGO} alt="School Logo" className="w-full h-full object-contain" />
          </div>
          <h1 className="text-sm font-bold text-amber-400 font-devanagari tracking-wide">
            राज कुमार सीताराम इण्टर कालेज
          </h1>
          <h2 className="text-base font-extrabold tracking-wide uppercase mt-0.5">
            RAJKUMAR SITARAM KISHAN INTER COLLEGE
          </h2>
          <p className="text-[11px] text-blue-200 uppercase mt-0.5">
            BAMDERA, BALPUR, GONDA, UTTAR PRADESH
          </p>
          <div className="mt-2.5 inline-block bg-blue-900/80 text-amber-300 border border-blue-700 text-[11px] font-bold px-3 py-0.5 rounded-full">
            Admit Card Management Portal
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {errorMsg && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {resetSent && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-600" />
              <span>Password reset link has been dispatched to {email}.</span>
            </div>
          )}

          {/* Dedicated Admin Credentials Helper Card */}
          <div className="bg-amber-50/90 border border-amber-300 rounded-xl p-3 mb-4 text-xs">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5 text-blue-950 font-extrabold text-[11px]">
                <Key className="w-3.5 h-3.5 text-amber-600" />
                <span>Default Admin Login Credentials</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEmail('admin@rskicgonda.org');
                  setPassword('admin123');
                }}
                className="text-[10px] bg-amber-200 hover:bg-amber-300 px-2 py-0.5 rounded-md font-bold text-blue-950 cursor-pointer transition-colors shadow-2xs"
              >
                Auto-fill
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2 font-mono text-[11px] bg-white p-2 rounded-lg border border-amber-200/80">
              <div>
                <span className="text-slate-500 font-sans block text-[9px] uppercase font-bold">Email ID:</span>
                <span className="font-bold text-blue-900 select-all">admin@rskicgonda.org</span>
              </div>
              <div>
                <span className="text-slate-500 font-sans block text-[9px] uppercase font-bold">Password:</span>
                <span className="font-bold text-slate-900 select-all">admin123</span>
              </div>
            </div>
          </div>

          {!showForgot ? (
            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Administrator Email:
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@rskicgonda.org"
                    className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600 font-medium"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">Password:</label>
                  <button
                    type="button"
                    onClick={() => setShowForgot(true)}
                    className="text-[11px] text-blue-800 font-semibold hover:underline cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600 font-medium"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                <LogIn className="w-4 h-4 text-amber-400" />
                <span>{loading ? 'Authenticating...' : 'Sign In as Administrator'}</span>
              </button>

              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-slate-200"></div>
                <span className="flex-shrink mx-3 text-slate-400 text-[11px] font-bold uppercase">
                  Or Sign In With
                </span>
                <div className="flex-grow border-t border-slate-200"></div>
              </div>

              {/* Google Sign-in */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-bold flex items-center justify-center gap-2 shadow-2xs transition-colors cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.03 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Google Sign-In</span>
              </button>

              {/* Demo Admin bypass */}
              <button
                type="button"
                onClick={loginAsDemoAdmin}
                className="w-full py-2 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-950 rounded-lg text-xs font-extrabold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Key className="w-3.5 h-3.5 text-amber-700" />
                <span>Instant Demo Admin Access</span>
              </button>
            </form>
          ) : (
            /* Forgot Password Form */
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <h3 className="text-xs font-bold text-slate-800">Reset Admin Password</h3>
              <p className="text-[11px] text-slate-500">
                Enter your registered admin email address and we will dispatch a reset link.
              </p>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email:</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@rskicgonda.org"
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowForgot(false)}
                  className="w-1/2 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  Back to Sign In
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-1/2 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-lg cursor-pointer"
                >
                  Send Reset Link
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-center text-[11px] text-slate-500">
          Rajkumar Sitaram Kishan Inter College, Gonda (U.P.)
        </div>

      </div>
    </div>
  );
};
