import React, { useState, useMemo } from 'react';
import { Student, ALL_CLASSES, ALL_SECTIONS, StudentClass, Section } from '../../types';
import {
  Search,
  UserPlus,
  FileSpreadsheet,
  Printer,
  Edit,
  Trash2,
  Filter,
  ArrowUpDown,
  Image as ImageIcon,
  CheckCircle2,
  AlertTriangle,
  Eye,
} from 'lucide-react';

interface StudentListProps {
  students: Student[];
  onAddStudent: () => void;
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (studentId: string) => void;
  onOpenExcelImport: () => void;
  onOpenBulkAdmitCards: () => void;
  onPreviewAdmitCard: (student: Student) => void;
}

export const StudentList: React.FC<StudentListProps> = ({
  students,
  onAddStudent,
  onEditStudent,
  onDeleteStudent,
  onOpenExcelImport,
  onOpenBulkAdmitCards,
  onPreviewAdmitCard,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClass, setSelectedClass] = useState<string>('ALL');
  const [selectedSection, setSelectedSection] = useState<string>('ALL');
  const [selectedGender, setSelectedGender] = useState<string>('ALL');
  const [selectedPhotoStatus, setSelectedPhotoStatus] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'roll' | 'name' | 'class'>('roll');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Filter & Search Logic
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      // Search matching across all designated fields
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = s.studentName.toLowerCase().includes(q);
        const matchesFather = s.fatherName.toLowerCase().includes(q);
        const matchesRoll = s.rollNumber.toLowerCase().includes(q);
        const matchesAdm = (s.admissionNumber || '').toLowerCase().includes(q);
        const matchesStudentId = (s.studentId || '').toLowerCase().includes(q);
        const matchesAdmitNum = s.admitCardNumber.toLowerCase().includes(q);

        if (
          !matchesName &&
          !matchesFather &&
          !matchesRoll &&
          !matchesAdm &&
          !matchesStudentId &&
          !matchesAdmitNum
        ) {
          return false;
        }
      }

      // Class Filter
      if (selectedClass !== 'ALL' && s.class !== selectedClass) return false;

      // Section Filter
      if (selectedSection !== 'ALL' && s.section !== selectedSection) return false;

      // Gender Filter
      if (selectedGender !== 'ALL' && s.gender !== selectedGender) return false;

      // Photo Status Filter
      if (selectedPhotoStatus === 'HAS_PHOTO' && !s.photoUrl) return false;
      if (selectedPhotoStatus === 'NO_PHOTO' && s.photoUrl) return false;

      return true;
    });
  }, [students, searchQuery, selectedClass, selectedSection, selectedGender, selectedPhotoStatus]);

  // Sorting Logic
  const sortedStudents = useMemo(() => {
    return [...filteredStudents].sort((a, b) => {
      let comp = 0;
      if (sortBy === 'roll') {
        const aNum = parseInt(a.rollNumber, 10);
        const bNum = parseInt(b.rollNumber, 10);
        if (!isNaN(aNum) && !isNaN(bNum)) {
          comp = aNum - bNum;
        } else {
          comp = a.rollNumber.localeCompare(b.rollNumber);
        }
      } else if (sortBy === 'name') {
        comp = a.studentName.localeCompare(b.studentName);
      } else if (sortBy === 'class') {
        comp = a.class.localeCompare(b.class);
      }
      return sortOrder === 'asc' ? comp : -comp;
    });
  }, [filteredStudents, sortBy, sortOrder]);

  const toggleSort = (type: 'roll' | 'name' | 'class') => {
    if (sortBy === type) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(type);
      setSortOrder('asc');
    }
  };

  return (
    <div className="space-y-4">
      
      {/* Top Banner & Quick Actions */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-blue-950 flex items-center gap-2">
            <span>Student Management</span>
            <span className="text-xs bg-blue-100 text-blue-800 font-extrabold px-2.5 py-0.5 rounded-full">
              {students.length} Total
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage student records, passport photos, and instant admit card generation
          </p>
        </div>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenExcelImport}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>Import Excel</span>
          </button>

          <button
            onClick={onOpenBulkAdmitCards}
            className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-blue-950 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Bulk Admit Cards</span>
          </button>

          <button
            onClick={onAddStudent}
            className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <UserPlus className="w-4 h-4 text-amber-400" />
            <span>+ Add Student</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 items-center">
          {/* Search input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Student Name, Father's Name, Roll No, Adm No, Admit Card No..."
              className="w-full text-xs pl-9 pr-4 py-2 rounded-lg border border-slate-300 focus:outline-blue-600 bg-slate-50/50"
            />
          </div>

          {/* Quick Filter dropdowns */}
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            {/* Class filter */}
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="text-xs px-2.5 py-2 rounded-lg border border-slate-300 bg-white font-medium focus:outline-blue-600"
            >
              <option value="ALL">All Classes</option>
              {ALL_CLASSES.map((cls) => (
                <option key={cls} value={cls}>
                  Class {cls}
                </option>
              ))}
            </select>

            {/* Section filter */}
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="text-xs px-2.5 py-2 rounded-lg border border-slate-300 bg-white font-medium focus:outline-blue-600"
            >
              <option value="ALL">All Sections</option>
              {ALL_SECTIONS.map((sec) => (
                <option key={sec} value={sec}>
                  Section {sec}
                </option>
              ))}
            </select>

            {/* Gender filter */}
            <select
              value={selectedGender}
              onChange={(e) => setSelectedGender(e.target.value)}
              className="text-xs px-2.5 py-2 rounded-lg border border-slate-300 bg-white font-medium focus:outline-blue-600"
            >
              <option value="ALL">All Genders</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>

            {/* Photo filter */}
            <select
              value={selectedPhotoStatus}
              onChange={(e) => setSelectedPhotoStatus(e.target.value)}
              className="text-xs px-2.5 py-2 rounded-lg border border-slate-300 bg-white font-medium focus:outline-blue-600"
            >
              <option value="ALL">All Photos</option>
              <option value="HAS_PHOTO">Photo Available</option>
              <option value="NO_PHOTO">Photo Missing</option>
            </select>
          </div>
        </div>

        {/* Active filtering info */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
          <span>
            Showing <strong className="text-blue-900">{sortedStudents.length}</strong> of{' '}
            {students.length} students
          </span>
          {(searchQuery ||
            selectedClass !== 'ALL' ||
            selectedSection !== 'ALL' ||
            selectedGender !== 'ALL' ||
            selectedPhotoStatus !== 'ALL') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedClass('ALL');
                setSelectedSection('ALL');
                setSelectedGender('ALL');
                setSelectedPhotoStatus('ALL');
              }}
              className="text-blue-800 font-bold hover:underline cursor-pointer"
            >
              Clear Filters
            </button>
          )}
        </div>
      </div>

      {/* Students Data Table */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-3 text-center w-14">Photo</th>
                <th
                  className="py-3 px-3 cursor-pointer hover:text-blue-900"
                  onClick={() => toggleSort('name')}
                >
                  <div className="flex items-center gap-1">
                    <span>Student Name</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-3">Father's Name</th>
                <th
                  className="py-3 px-3 text-center cursor-pointer hover:text-blue-900"
                  onClick={() => toggleSort('class')}
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>Class & Sec</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  className="py-3 px-3 text-center cursor-pointer hover:text-blue-900"
                  onClick={() => toggleSort('roll')}
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>Roll No</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-3">Admit Card No.</th>
                <th className="py-3 px-3 text-center">Gender / DOB</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sortedStudents.map((s) => (
                <tr key={s.id} className="hover:bg-blue-50/40 transition-colors">
                  {/* Photo */}
                  <td className="py-2 px-3 text-center">
                    <div className="w-9 h-11 rounded border border-slate-300 bg-slate-100 overflow-hidden mx-auto flex items-center justify-center shadow-2xs">
                      {s.photoUrl ? (
                        <img
                          src={s.photoUrl}
                          alt={s.studentName}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-[9px] font-bold text-slate-400">NO PIC</span>
                      )}
                    </div>
                  </td>

                  {/* Name & ID */}
                  <td className="py-2 px-3">
                    <div className="font-bold text-slate-900 text-sm">{s.studentName}</div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      ID: {s.studentId || s.admissionNumber || 'RSKIC-ST'}
                    </div>
                  </td>

                  {/* Father Name */}
                  <td className="py-2 px-3 text-slate-700 font-medium">
                    <div>{s.fatherName}</div>
                    {s.motherName && (
                      <div className="text-[10px] text-slate-400">M: {s.motherName}</div>
                    )}
                  </td>

                  {/* Class & Section */}
                  <td className="py-2 px-3 text-center">
                    <span className="inline-block px-2 py-0.5 rounded font-extrabold bg-blue-100 text-blue-900 text-xs">
                      {s.class}-{s.section}
                    </span>
                  </td>

                  {/* Roll Number */}
                  <td className="py-2 px-3 text-center">
                    <span className="font-mono font-black text-slate-900 text-sm">
                      {s.rollNumber}
                    </span>
                  </td>

                  {/* Admit Card Number */}
                  <td className="py-2 px-3">
                    <span className="font-mono font-bold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded text-[11px]">
                      {s.admitCardNumber}
                    </span>
                  </td>

                  {/* Gender / DOB */}
                  <td className="py-2 px-3 text-center text-slate-600 text-[11px]">
                    <div>{s.gender}</div>
                    <div className="text-[10px] text-slate-400">{s.dob || '—'}</div>
                  </td>

                  {/* Actions */}
                  <td className="py-2 px-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => onPreviewAdmitCard(s)}
                        className="px-2.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded-md text-xs font-bold flex items-center gap-1 shadow-2xs transition-colors cursor-pointer"
                        title="View / Print Admit Card"
                      >
                        <Eye className="w-3.5 h-3.5 text-amber-400" />
                        <span>Admit Card</span>
                      </button>

                      <button
                        onClick={() => onEditStudent(s)}
                        className="p-1.5 text-slate-600 hover:text-blue-900 hover:bg-blue-50 rounded-md transition-colors cursor-pointer"
                        title="Edit Student Details"
                      >
                        <Edit className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => setDeleteConfirmId(s.id)}
                        className="p-1.5 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-md transition-colors cursor-pointer"
                        title="Delete Student"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {sortedStudents.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <p className="font-semibold text-sm">No students match your query.</p>
                    <p className="text-xs mt-1">Try adjusting the search criteria or add new students.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-5 border border-slate-200">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <AlertTriangle className="w-6 h-6" />
              <h4 className="font-bold text-base text-slate-900">Delete Student Record?</h4>
            </div>
            <p className="text-xs text-slate-600 mb-5">
              This will permanently delete this student and their generated admit card. This action cannot be undone.
            </p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteStudent(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="px-4 py-1.5 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg cursor-pointer"
              >
                Delete Student
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
