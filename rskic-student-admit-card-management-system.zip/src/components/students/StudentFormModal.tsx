import React, { useState, useEffect } from 'react';
import { Student, ALL_CLASSES, ALL_SECTIONS, Gender, StudentClass, Section } from '../../types';
import { X, Upload, Camera, Trash2, CheckCircle2 } from 'lucide-react';

interface StudentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (student: Student) => Promise<void>;
  studentToEdit?: Student | null;
  suggestedAdmitCardNumber: string;
}

export const StudentFormModal: React.FC<StudentFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  studentToEdit,
  suggestedAdmitCardNumber,
}) => {
  const [formData, setFormData] = useState<Partial<Student>>({
    studentName: '',
    fatherName: '',
    motherName: '',
    class: '10',
    section: 'A',
    rollNumber: '',
    dob: '2010-01-01',
    gender: 'Male',
    photoUrl: '',
    admissionNumber: '',
    studentId: '',
    admitCardNumber: '',
  });

  const [saving, setSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (studentToEdit) {
      setFormData(studentToEdit);
    } else {
      setFormData({
        studentName: '',
        fatherName: '',
        motherName: '',
        class: '10',
        section: 'A',
        rollNumber: '',
        dob: '2010-01-01',
        gender: 'Male',
        photoUrl: '',
        admissionNumber: '',
        studentId: '',
        admitCardNumber: suggestedAdmitCardNumber,
      });
    }
    setErrorMessage('');
  }, [studentToEdit, suggestedAdmitCardNumber, isOpen]);

  if (!isOpen) return null;

  // Handle Photo upload with resize & compression to clean DataURL
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/jpeg', 'image/png', 'image/jpg', 'image/webp'].includes(file.type)) {
      setErrorMessage('Please upload a valid JPG or PNG image.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Resize to standard passport photo resolution (300 x 360)
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const targetWidth = 300;
        const targetHeight = 360;
        canvas.width = targetWidth;
        canvas.height = targetHeight;

        // Draw and compress
        if (ctx) {
          ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.82);
          setFormData((prev) => ({ ...prev, photoUrl: compressedDataUrl }));
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleRemovePhoto = () => {
    setFormData((prev) => ({ ...prev, photoUrl: '' }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.studentName?.trim()) {
      setErrorMessage('Please enter Student Name.');
      return;
    }

    if (!formData.fatherName?.trim()) {
      setErrorMessage("Please enter Father's Name.");
      return;
    }

    if (!formData.rollNumber?.trim()) {
      setErrorMessage('Please enter Roll Number.');
      return;
    }

    if (!formData.admitCardNumber?.trim()) {
      formData.admitCardNumber = suggestedAdmitCardNumber;
    }

    try {
      setSaving(true);
      const studentPayload: Student = {
        id: studentToEdit?.id || `stud-${Date.now()}`,
        studentName: formData.studentName.trim(),
        fatherName: formData.fatherName.trim(),
        motherName: formData.motherName?.trim() || '',
        class: (formData.class as StudentClass) || '10',
        section: (formData.section as Section) || 'A',
        rollNumber: formData.rollNumber.trim(),
        dob: formData.dob || '',
        gender: (formData.gender as Gender) || 'Male',
        photoUrl: formData.photoUrl || '',
        admissionNumber: formData.admissionNumber?.trim() || '',
        studentId: formData.studentId?.trim() || (formData.rollNumber ? `RSKIC-${formData.rollNumber}` : ''),
        admitCardNumber: formData.admitCardNumber.trim(),
        createdAt: studentToEdit?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSave(studentPayload);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save student record.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-blue-950 text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-lg leading-tight">
              {studentToEdit ? 'Edit Student Details' : 'Add New Student'}
            </h3>
            <p className="text-xs text-blue-200">
              Enter academic credentials and upload passport photograph
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-blue-900 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg font-medium">
              ⚠️ {errorMessage}
            </div>
          )}

          {/* Photo and Primary ID section */}
          <div className="flex flex-col sm:flex-row items-center gap-5 p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
            {/* Photo Box */}
            <div className="relative group w-24 h-28 border-2 border-dashed border-blue-900/40 rounded-lg bg-white overflow-hidden flex items-center justify-center flex-shrink-0 shadow-inner">
              {formData.photoUrl ? (
                <>
                  <img
                    src={formData.photoUrl}
                    alt="Student Preview"
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    className="absolute top-1 right-1 p-1 bg-red-600 text-white rounded-full opacity-80 hover:opacity-100 transition-opacity cursor-pointer shadow-xs"
                    title="Remove Photo"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </>
              ) : (
                <div className="text-center p-2 text-slate-400">
                  <Camera className="w-6 h-6 mx-auto mb-1 text-slate-400" />
                  <span className="text-[10px] font-semibold block leading-tight">Add Photo</span>
                </div>
              )}
            </div>

            {/* Photo Upload Input & Auto Admit Card Number */}
            <div className="flex-1 w-full space-y-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Student Passport Photograph (JPG / PNG):
                </label>
                <div className="flex items-center gap-2">
                  <label className="px-3 py-1.5 bg-blue-50 border border-blue-300 hover:bg-blue-100 text-blue-900 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Browse & Upload</span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/jpg"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </label>
                  <span className="text-[11px] text-slate-500">Auto-cropped for Admit Card</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Admit Card Number (Auto-Generated):
                </label>
                <input
                  type="text"
                  value={formData.admitCardNumber || ''}
                  onChange={(e) => setFormData({ ...formData, admitCardNumber: e.target.value })}
                  placeholder="RSKIC-2026-0001"
                  className="w-full text-xs font-bold px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-blue-900 focus:outline-blue-600"
                />
              </div>
            </div>
          </div>

          {/* Form Fields Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Student Name <span className="text-red-500">*</span>:
              </label>
              <input
                type="text"
                required
                value={formData.studentName || ''}
                onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                placeholder="e.g. Rahul Kumar"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Father's Name <span className="text-red-500">*</span>:
              </label>
              <input
                type="text"
                required
                value={formData.fatherName || ''}
                onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                placeholder="e.g. Raj Kumar"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Mother's Name:</label>
              <input
                type="text"
                value={formData.motherName || ''}
                onChange={(e) => setFormData({ ...formData, motherName: e.target.value })}
                placeholder="e.g. Sita Devi"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Date of Birth (DOB):</label>
              <input
                type="date"
                value={formData.dob || ''}
                onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Class <span className="text-red-500">*</span>:
                </label>
                <select
                  value={formData.class || '10'}
                  onChange={(e) => setFormData({ ...formData, class: e.target.value as StudentClass })}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-blue-600"
                >
                  {ALL_CLASSES.map((cls) => (
                    <option key={cls} value={cls}>
                      Class {cls}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Section:
                </label>
                <select
                  value={formData.section || 'A'}
                  onChange={(e) => setFormData({ ...formData, section: e.target.value as Section })}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-blue-600"
                >
                  {ALL_SECTIONS.map((sec) => (
                    <option key={sec} value={sec}>
                      Section {sec}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Roll Number <span className="text-red-500">*</span>:
                </label>
                <input
                  type="text"
                  required
                  value={formData.rollNumber || ''}
                  onChange={(e) => setFormData({ ...formData, rollNumber: e.target.value })}
                  placeholder="e.g. 101"
                  className="w-full text-xs font-bold px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Gender:</label>
                <select
                  value={formData.gender || 'Male'}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value as Gender })}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-blue-600"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Admission Number:</label>
              <input
                type="text"
                value={formData.admissionNumber || ''}
                onChange={(e) => setFormData({ ...formData, admissionNumber: e.target.value })}
                placeholder="e.g. ADM-2022-452"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Student ID:</label>
              <input
                type="text"
                value={formData.studentId || ''}
                onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                placeholder="e.g. RSKIC-ST-101"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-bold bg-blue-900 hover:bg-blue-800 text-white rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 shadow-xs"
            >
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>{saving ? 'Saving...' : studentToEdit ? 'Update Student' : 'Save Student'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
