import React, { useState } from 'react';
import { Student } from '../../types';
import { excelService, ParsedRowResult } from '../../services/excelService';
import { X, Upload, FileSpreadsheet, Download, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';

interface ExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  existingStudents: Student[];
  onImportSuccess: (importedStudents: Student[]) => Promise<void>;
  getNextAdmitCardNumber: (existing: Student[]) => string;
}

export const ExcelImportModal: React.FC<ExcelImportModalProps> = ({
  isOpen,
  onClose,
  existingStudents,
  onImportSuccess,
  getNextAdmitCardNumber,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [parsing, setParsing] = useState(false);
  const [importing, setImporting] = useState(false);
  const [parseResults, setParseResults] = useState<ParsedRowResult[] | null>(null);
  const [stats, setStats] = useState({ validCount: 0, errorCount: 0 });
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);
    setErrorMsg('');
    try {
      setParsing(true);
      const { results, validCount, errorCount } = await excelService.parseAndValidate(
        selectedFile,
        existingStudents
      );
      setParseResults(results);
      setStats({ validCount, errorCount });
    } catch (err: any) {
      setErrorMsg(err.message || 'Please upload a valid Excel or CSV file.');
      setParseResults(null);
    } finally {
      setParsing(false);
    }
  };

  const handleDownloadTemplate = () => {
    excelService.downloadTemplate();
  };

  const handleExecuteImport = async () => {
    if (!parseResults) return;

    const validRows = parseResults.filter((r) => r.isValid);
    if (validRows.length === 0) {
      setErrorMsg('No valid records to import.');
      return;
    }

    try {
      setImporting(true);
      let currentStudentList = [...existingStudents];
      const studentsToInsert: Student[] = [];

      for (const row of validRows) {
        const autoAdmitCardNumber = getNextAdmitCardNumber(currentStudentList);
        const newStudent: Student = {
          id: `stud-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          studentName: row.data.studentName || '',
          fatherName: row.data.fatherName || '',
          motherName: row.data.motherName || '',
          class: row.data.class || '10',
          section: row.data.section || 'A',
          rollNumber: row.data.rollNumber || '',
          dob: row.data.dob || '',
          gender: row.data.gender || 'Male',
          admissionNumber: row.data.admissionNumber || '',
          studentId: row.data.studentId || '',
          admitCardNumber: autoAdmitCardNumber,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        studentsToInsert.push(newStudent);
        currentStudentList.push(newStudent);
      }

      await onImportSuccess(studentsToInsert);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Import failed.');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="px-6 py-4 bg-blue-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-800 rounded-lg text-emerald-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">Bulk Import Students from Excel / CSV</h3>
              <p className="text-xs text-blue-200">
                Upload hundreds of students in one click with instant validation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-blue-900 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar / Template download */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <label className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer shadow-xs transition-colors">
              <Upload className="w-4 h-4 text-amber-400" />
              <span>{file ? 'Choose Different File' : 'Select Excel / CSV File'}</span>
              <input
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
            {file && (
              <span className="text-xs font-semibold text-slate-700">
                📄 {file.name} ({(file.size / 1024).toFixed(1)} KB)
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={handleDownloadTemplate}
            className="px-3.5 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 rounded-lg text-xs font-bold flex items-center gap-2 shadow-xs cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>Download Excel Template (.xlsx)</span>
          </button>
        </div>

        {/* Content & Preview */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {parsing && (
            <div className="py-12 text-center text-slate-500">
              <Loader2 className="w-8 h-8 mx-auto animate-spin text-blue-900 mb-2" />
              <p className="font-semibold text-sm">Analyzing rows and validating records...</p>
            </div>
          )}

          {!file && !parsing && (
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center bg-slate-50/50">
              <FileSpreadsheet className="w-12 h-12 mx-auto text-slate-400 mb-3" />
              <h4 className="font-bold text-slate-800 text-sm">Upload Student Excel Sheet</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
                Supported formats: <strong>.xlsx, .xls, .csv</strong>. Columns include Student Name, Father's Name, Class, Section, Roll Number, Date of Birth, Gender, etc.
              </p>
              <button
                onClick={handleDownloadTemplate}
                className="inline-flex items-center gap-1.5 text-xs text-blue-800 font-bold underline hover:text-blue-900"
              >
                <Download className="w-3.5 h-3.5" />
                Don't have a template? Download the official RSKIC template here
              </button>
            </div>
          )}

          {parseResults && !parsing && (
            <div>
              {/* Validation Stats summary */}
              <div className="flex items-center gap-3 mb-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{stats.validCount} Valid Records Ready to Import</span>
                </div>
                {stats.errorCount > 0 && (
                  <div className="flex items-center gap-1.5 text-xs font-bold text-red-800 bg-red-50 border border-red-200 px-3 py-1.5 rounded-lg">
                    <AlertCircle className="w-4 h-4 text-red-600" />
                    <span>{stats.errorCount} Records with Errors (Will be Skipped)</span>
                  </div>
                )}
              </div>

              {/* Data Preview Table */}
              <div className="border border-slate-200 rounded-lg overflow-x-auto max-h-80 shadow-inner">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-slate-100 text-slate-700 sticky top-0 border-b border-slate-200">
                    <tr>
                      <th className="py-2 px-2 text-center w-12">Row</th>
                      <th className="py-2 px-2 text-center w-20">Status</th>
                      <th className="py-2 px-3">Student Name</th>
                      <th className="py-2 px-3">Father's Name</th>
                      <th className="py-2 px-2 text-center">Class</th>
                      <th className="py-2 px-2 text-center">Sec</th>
                      <th className="py-2 px-2 text-center">Roll No</th>
                      <th className="py-2 px-3">Issues / Errors</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parseResults.map((res) => (
                      <tr
                        key={res.rowNumber}
                        className={`border-b border-slate-200 ${
                          res.isValid ? 'bg-white hover:bg-slate-50' : 'bg-red-50/70 text-red-900'
                        }`}
                      >
                        <td className="py-1.5 px-2 text-center font-mono text-slate-500">
                          {res.rowNumber}
                        </td>
                        <td className="py-1.5 px-2 text-center">
                          {res.isValid ? (
                            <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                              VALID
                            </span>
                          ) : (
                            <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-red-200 text-red-800">
                              ERROR
                            </span>
                          )}
                        </td>
                        <td className="py-1.5 px-3 font-bold text-slate-800">
                          {res.data.studentName || '—'}
                        </td>
                        <td className="py-1.5 px-3 text-slate-700">
                          {res.data.fatherName || '—'}
                        </td>
                        <td className="py-1.5 px-2 text-center font-bold text-blue-900">
                          {res.data.class || '—'}
                        </td>
                        <td className="py-1.5 px-2 text-center text-slate-700">
                          {res.data.section || 'A'}
                        </td>
                        <td className="py-1.5 px-2 text-center font-mono font-bold text-slate-900">
                          {res.data.rollNumber || '—'}
                        </td>
                        <td className="py-1.5 px-3">
                          {res.errors.length > 0 ? (
                            <div className="space-y-0.5">
                              {res.errors.map((e, idx) => (
                                <span
                                  key={idx}
                                  className="inline-block text-[10px] font-medium text-red-700 bg-red-100 px-1.5 py-0.5 rounded mr-1"
                                >
                                  {e}
                                </span>
                              ))}
                            </div>
                          ) : (
                            <span className="text-[10px] text-emerald-700 font-semibold">Ready</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-white border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
          >
            Cancel
          </button>

          <button
            onClick={handleExecuteImport}
            disabled={!parseResults || stats.validCount === 0 || importing}
            className="px-5 py-2 text-xs font-bold bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg flex items-center gap-2 transition-colors cursor-pointer disabled:opacity-50 shadow-xs"
          >
            {importing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Importing records...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Import {stats.validCount} Valid Records</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
