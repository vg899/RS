import React from 'react';
import { Student, Exam, TimetableEntry, ActivityLog, ALL_CLASSES } from '../../types';
import {
  Users,
  GraduationCap,
  Calendar,
  Printer,
  Camera,
  CameraOff,
  UserPlus,
  FileSpreadsheet,
  Clock,
  ArrowRight,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

interface DashboardOverviewProps {
  students: Student[];
  exams: Exam[];
  timetables: TimetableEntry[];
  activeExam: Exam;
  activities: ActivityLog[];
  onNavigate: (tab: 'students' | 'exams' | 'timetable' | 'settings') => void;
  onAddStudent: () => void;
  onOpenExcelImport: () => void;
  onOpenBulkAdmitCards: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  students,
  exams,
  timetables,
  activeExam,
  activities,
  onNavigate,
  onAddStudent,
  onOpenExcelImport,
  onOpenBulkAdmitCards,
}) => {
  const studentsWithPhoto = students.filter((s) => Boolean(s.photoUrl)).length;
  const studentsWithoutPhoto = students.length - studentsWithPhoto;
  const classesRepresented = new Set(students.map((s) => s.class)).size;

  return (
    <div className="space-y-5">
      {/* Active Exam Hero Announcement Card */}
      <div className="bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-950 text-white rounded-2xl p-6 shadow-md border border-blue-900/40 relative overflow-hidden">
        {/* Background decorative glow */}
        <div className="absolute right-0 top-0 w-80 h-full opacity-10 bg-gradient-to-l from-amber-400 to-transparent pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/30 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>ACTIVE SESSION: {activeExam.session || '2026-27'}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              {activeExam.examName || 'Half Yearly Examination 2026-27'}
            </h1>
            <p className="text-xs sm:text-sm text-blue-200 mt-1 max-w-xl">
              Centre: {activeExam.centre} • Default Timing: {activeExam.defaultExamTime} (Reporting: {activeExam.reportingTime})
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenBulkAdmitCards}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-blue-950 rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer shadow-md hover:shadow-lg"
            >
              <Printer className="w-4 h-4" />
              <span>Generate Bulk Admit Cards</span>
            </button>
            <button
              onClick={() => onNavigate('timetable')}
              className="px-4 py-2.5 bg-blue-800/80 hover:bg-blue-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer border border-blue-700/60"
            >
              <Clock className="w-4 h-4 text-amber-400" />
              <span>Timetable Matrix</span>
            </button>
          </div>
        </div>
      </div>

      {/* 6 KEY STATS CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Total Students */}
        <div
          onClick={() => onNavigate('students')}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs hover:border-blue-400 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-blue-600 mb-2">
            <Users className="w-5 h-5" />
            <span className="text-[10px] font-bold text-slate-400">Total</span>
          </div>
          <div className="text-2xl font-black text-slate-900">{students.length}</div>
          <div className="text-[11px] font-semibold text-slate-500 mt-0.5">Total Students</div>
        </div>

        {/* Total Classes */}
        <div
          onClick={() => onNavigate('students')}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs hover:border-blue-400 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-indigo-600 mb-2">
            <GraduationCap className="w-5 h-5" />
            <span className="text-[10px] font-bold text-slate-400">Classes</span>
          </div>
          <div className="text-2xl font-black text-slate-900">{classesRepresented} / 15</div>
          <div className="text-[11px] font-semibold text-slate-500 mt-0.5">Classes Enrolled</div>
        </div>

        {/* Total Exams */}
        <div
          onClick={() => onNavigate('exams')}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs hover:border-blue-400 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-emerald-600 mb-2">
            <Calendar className="w-5 h-5" />
            <span className="text-[10px] font-bold text-slate-400">Exams</span>
          </div>
          <div className="text-2xl font-black text-slate-900">{exams.length}</div>
          <div className="text-[11px] font-semibold text-slate-500 mt-0.5">Total Exams</div>
        </div>

        {/* Total Admit Cards */}
        <div
          onClick={onOpenBulkAdmitCards}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs hover:border-blue-400 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-amber-600 mb-2">
            <Printer className="w-5 h-5" />
            <span className="text-[10px] font-bold text-slate-400">Ready</span>
          </div>
          <div className="text-2xl font-black text-slate-900">{students.length}</div>
          <div className="text-[11px] font-semibold text-slate-500 mt-0.5">Admit Cards Ready</div>
        </div>

        {/* Photos Available */}
        <div
          onClick={() => onNavigate('students')}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs hover:border-blue-400 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-teal-600 mb-2">
            <Camera className="w-5 h-5" />
            <span className="text-[10px] font-bold text-emerald-600">✓ Photos</span>
          </div>
          <div className="text-2xl font-black text-slate-900">{studentsWithPhoto}</div>
          <div className="text-[11px] font-semibold text-slate-500 mt-0.5">With Photo</div>
        </div>

        {/* Photos Missing */}
        <div
          onClick={() => onNavigate('students')}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs hover:border-blue-400 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-red-500 mb-2">
            <CameraOff className="w-5 h-5" />
            <span className="text-[10px] font-bold text-red-600">Need Pic</span>
          </div>
          <div className="text-2xl font-black text-slate-900">{studentsWithoutPhoto}</div>
          <div className="text-[11px] font-semibold text-slate-500 mt-0.5">Without Photo</div>
        </div>
      </div>

      {/* QUICK ACTIONS BAR */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
          Quick Actions
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          <button
            onClick={onAddStudent}
            className="p-3 bg-blue-50/70 hover:bg-blue-100/70 text-blue-950 rounded-xl border border-blue-200/60 font-bold text-xs flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer text-center"
          >
            <UserPlus className="w-4 h-4 text-blue-800" />
            <span>+ Add Student</span>
          </button>

          <button
            onClick={onOpenExcelImport}
            className="p-3 bg-emerald-50/70 hover:bg-emerald-100/70 text-emerald-950 rounded-xl border border-emerald-200/60 font-bold text-xs flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer text-center"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-800" />
            <span>Import Excel</span>
          </button>

          <button
            onClick={() => onNavigate('exams')}
            className="p-3 bg-indigo-50/70 hover:bg-indigo-100/70 text-indigo-950 rounded-xl border border-indigo-200/60 font-bold text-xs flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer text-center"
          >
            <Calendar className="w-4 h-4 text-indigo-800" />
            <span>Create / Edit Exam</span>
          </button>

          <button
            onClick={() => onNavigate('timetable')}
            className="p-3 bg-purple-50/70 hover:bg-purple-100/70 text-purple-950 rounded-xl border border-purple-200/60 font-bold text-xs flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer text-center"
          >
            <Clock className="w-4 h-4 text-purple-800" />
            <span>Manage Timetable</span>
          </button>

          <button
            onClick={onOpenBulkAdmitCards}
            className="p-3 bg-amber-50/70 hover:bg-amber-100/70 text-amber-950 rounded-xl border border-amber-300 font-bold text-xs flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer text-center col-span-2 sm:col-span-1"
          >
            <Printer className="w-4 h-4 text-amber-800" />
            <span>Generate Admit Cards</span>
          </button>
        </div>
      </div>

      {/* LOWER SECTION: Activity Log & Class Enrollment Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Recent Activity Log */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-800" />
              <span>Recent Activity</span>
            </h3>
            <span className="text-[11px] text-slate-400">Real-time log</span>
          </div>

          <div className="space-y-3">
            {activities.slice(0, 6).map((log) => (
              <div key={log.id} className="flex items-start gap-3 text-xs">
                <div className="w-2 h-2 rounded-full bg-blue-600 mt-1.5 flex-shrink-0"></div>
                <div className="flex-1">
                  <p className="font-medium text-slate-800 leading-snug">{log.message}</p>
                  <span className="text-[10px] text-slate-400">
                    {new Date(log.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}{' '}
                    • {new Date(log.timestamp).toLocaleDateString('en-GB')}
                  </span>
                </div>
              </div>
            ))}

            {activities.length === 0 && (
              <p className="text-xs text-slate-400 italic py-4 text-center">No recent activities.</p>
            )}
          </div>
        </div>

        {/* Class Enrollment Breakdown */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-blue-800" />
              <span>Class Students Breakdown</span>
            </h3>
            <button
              onClick={() => onNavigate('students')}
              className="text-xs font-bold text-blue-800 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {ALL_CLASSES.map((cls) => {
              const count = students.filter((s) => s.class === cls).length;
              return (
                <div
                  key={cls}
                  onClick={() => onNavigate('students')}
                  className={`p-2 rounded-lg border text-center transition-colors cursor-pointer ${
                    count > 0
                      ? 'bg-blue-50/50 border-blue-200 hover:bg-blue-100/60'
                      : 'bg-slate-50 border-slate-100 opacity-60'
                  }`}
                >
                  <div className="text-[11px] font-bold text-slate-600">Class {cls}</div>
                  <div className="text-base font-black text-blue-950 mt-0.5">{count}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
