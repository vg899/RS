import React, { useState } from 'react';
import { TimetableEntry, StudentClass, ALL_CLASSES } from '../../types';
import { Plus, Edit, Trash2, Calendar, Filter, Copy, Table, List, CheckCircle2 } from 'lucide-react';

interface TimetableManagementProps {
  timetables: TimetableEntry[];
  activeExamId: string;
  onSaveEntry: (entry: TimetableEntry) => Promise<void>;
  onDeleteEntry: (entryId: string) => Promise<void>;
}

export const TimetableManagement: React.FC<TimetableManagementProps> = ({
  timetables,
  activeExamId,
  onSaveEntry,
  onDeleteEntry,
}) => {
  const [viewMode, setViewMode] = useState<'matrix' | 'list'>('matrix');
  const [selectedClass, setSelectedClass] = useState<string>('ALL');
  const [selectedDate, setSelectedDate] = useState<string>('ALL');
  const [editingEntry, setEditingEntry] = useState<TimetableEntry | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  // Distinct dates present in timetable
  const distinctDates = Array.from(new Set(timetables.map((t) => t.date))).sort();

  // Matrix classes: 6 to 12 as per official sheet, or all
  const matrixClasses: StudentClass[] = ['6', '7', '8', '9', '10', '11', '12'];

  // Filtered entries for list view
  const filteredEntries = timetables.filter((t) => {
    if (selectedClass !== 'ALL' && t.class !== selectedClass) return false;
    if (selectedDate !== 'ALL' && t.date !== selectedDate) return false;
    return true;
  });

  const handleOpenAdd = () => {
    setEditingEntry({
      id: `tt-${Date.now()}`,
      examId: activeExamId,
      date: '12/10/2026',
      class: '10',
      subject: '',
      examTime: '10:30 AM - 01:00 PM',
      reportingTime: '10:00 AM',
      roomCentre: '',
      remarks: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (entry: TimetableEntry) => {
    setEditingEntry({ ...entry });
    setIsModalOpen(true);
  };

  const handleDuplicate = async (entry: TimetableEntry) => {
    const duplicated: TimetableEntry = {
      ...entry,
      id: `tt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    };
    await onSaveEntry(duplicated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEntry || !editingEntry.subject.trim() || !editingEntry.date.trim()) return;

    try {
      setSaving(true);
      await onSaveEntry(editingEntry);
      setIsModalOpen(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-blue-950 flex items-center gap-2">
            <span>Examination Timetable Management</span>
            <span className="text-xs bg-blue-100 text-blue-900 font-extrabold px-2.5 py-0.5 rounded-full">
              {timetables.length} Schedules
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Full subject schedules mapped to student admit cards by class and date (Hindi & English compatible)
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Switch Matrix / List view */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            <button
              onClick={() => setViewMode('matrix')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                viewMode === 'matrix'
                  ? 'bg-white text-blue-950 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Table className="w-3.5 h-3.5" />
              <span>Matrix Sheet</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-white text-blue-950 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Detail List</span>
            </button>
          </div>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>+ Add Timetable Entry</span>
          </button>
        </div>
      </div>

      {/* MATRIX VIEW (Exact replica of the College's original printed timetable sheet from the image!) */}
      {viewMode === 'matrix' && (
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div>
              <h3 className="font-bold text-sm text-blue-950 flex items-center gap-2">
                <span>School Master Schedule Matrix (कक्षा 6 से 12 परीक्षा सारिणी)</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Matches the original RSKIC college timetable layout. Click any cell to view or modify.
              </p>
            </div>
            <span className="text-xs font-bold text-blue-900 bg-blue-50 px-2.5 py-1 rounded">
              Default Exam Time: 10:30 AM to 01:00 PM
            </span>
          </div>

          <div className="overflow-x-auto border border-slate-300 rounded-lg">
            <table className="w-full text-xs text-center border-collapse">
              <thead>
                <tr className="bg-blue-950 text-white font-bold">
                  <th className="py-2.5 px-3 border-r border-blue-900 w-28">दिनांक (Date)</th>
                  {matrixClasses.map((cls) => (
                    <th key={cls} className="py-2.5 px-2 border-r border-blue-900 min-w-28">
                      कक्षा-{cls}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {distinctDates.map((dateStr, idx) => (
                  <tr
                    key={dateStr}
                    className={`hover:bg-blue-50/50 transition-colors ${
                      idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'
                    }`}
                  >
                    {/* Date column */}
                    <td className="py-3 px-3 font-mono font-bold text-blue-950 border-r border-slate-200 bg-slate-100/70">
                      {dateStr}
                    </td>

                    {/* Class columns */}
                    {matrixClasses.map((cls) => {
                      const entry = timetables.find(
                        (t) => t.date === dateStr && String(t.class).trim() === cls
                      );

                      return (
                        <td
                          key={cls}
                          className="py-2 px-2 border-r border-slate-200 text-slate-800 text-left align-top"
                        >
                          {entry ? (
                            <div className="group relative p-1 rounded hover:bg-amber-50 transition-colors">
                              <div className="font-bold text-xs text-slate-900 font-devanagari leading-snug">
                                {entry.subject}
                              </div>
                              <div className="text-[10px] text-slate-500 mt-0.5">
                                {entry.examTime}
                              </div>
                              <button
                                onClick={() => handleOpenEdit(entry)}
                                className="opacity-0 group-hover:opacity-100 absolute top-1 right-1 p-1 bg-white border border-slate-300 shadow-xs rounded text-blue-900 hover:bg-blue-50 cursor-pointer"
                                title="Edit Entry"
                              >
                                <Edit className="w-3 h-3" />
                              </button>
                            </div>
                          ) : (
                            <div className="text-slate-300 text-center py-2 font-mono">—</div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DETAIL LIST VIEW */}
      {viewMode === 'list' && (
        <div className="space-y-3">
          {/* Filters */}
          <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 flex flex-wrap gap-3 items-center">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-700">Filter Class:</span>
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
              >
                <option value="ALL">All Classes</option>
                {ALL_CLASSES.map((c) => (
                  <option key={c} value={c}>
                    Class {c}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-700">Filter Date:</span>
              <select
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
              >
                <option value="ALL">All Dates</option>
                {distinctDates.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <span className="text-xs text-slate-500 ml-auto">
              Showing {filteredEntries.length} entries
            </span>
          </div>

          {/* List Table */}
          <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3 text-center">Class</th>
                  <th className="py-2.5 px-3">Subject (विषय)</th>
                  <th className="py-2.5 px-3">Exam Timing</th>
                  <th className="py-2.5 px-3">Reporting</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredEntries.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-blue-900">{item.date}</td>
                    <td className="py-2 px-3 text-center">
                      <span className="px-2 py-0.5 bg-blue-100 text-blue-900 rounded font-bold">
                        Class {item.class}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-bold text-slate-900 font-devanagari text-sm">
                      {item.subject}
                    </td>
                    <td className="py-2 px-3 text-slate-700 font-medium">{item.examTime}</td>
                    <td className="py-2 px-3 text-slate-600">{item.reportingTime}</td>
                    <td className="py-2 px-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => handleDuplicate(item)}
                          className="p-1.5 text-slate-500 hover:text-blue-900 hover:bg-blue-50 rounded"
                          title="Duplicate to another entry"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 text-blue-900 hover:bg-blue-50 rounded"
                          title="Edit"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteEntry(item.id)}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Timetable Modal */}
      {isModalOpen && editingEntry && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="px-6 py-4 bg-blue-950 text-white flex items-center justify-between">
              <h3 className="font-bold text-base">
                {editingEntry.id ? 'Edit Timetable Schedule' : 'Add Timetable Schedule'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-300 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Exam Date (DD/MM/YYYY):
                  </label>
                  <input
                    type="text"
                    required
                    value={editingEntry.date}
                    onChange={(e) => setEditingEntry({ ...editingEntry, date: e.target.value })}
                    placeholder="12/10/2026"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Class:</label>
                  <select
                    value={editingEntry.class}
                    onChange={(e) =>
                      setEditingEntry({ ...editingEntry, class: e.target.value as StudentClass })
                    }
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-blue-600"
                  >
                    {ALL_CLASSES.map((cls) => (
                      <option key={cls} value={cls}>
                        Class {cls}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Subject (Hindi / English):
                </label>
                <input
                  type="text"
                  required
                  value={editingEntry.subject}
                  onChange={(e) => setEditingEntry({ ...editingEntry, subject: e.target.value })}
                  placeholder="e.g. Science (विज्ञान) or Mathematics (गणित)"
                  className="w-full text-xs font-medium px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600 font-devanagari"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Exam Time:</label>
                  <input
                    type="text"
                    required
                    value={editingEntry.examTime}
                    onChange={(e) => setEditingEntry({ ...editingEntry, examTime: e.target.value })}
                    placeholder="10:30 AM - 01:00 PM"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Reporting Time:
                  </label>
                  <input
                    type="text"
                    required
                    value={editingEntry.reportingTime}
                    onChange={(e) =>
                      setEditingEntry({ ...editingEntry, reportingTime: e.target.value })
                    }
                    placeholder="10:00 AM"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 text-xs font-bold bg-blue-900 hover:bg-blue-800 text-white rounded-lg cursor-pointer"
                >
                  {saving ? 'Saving...' : 'Save Schedule'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
