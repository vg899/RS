import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { SchoolSettings, Exam } from '../../types';
import { LogOut, Menu, User, BookOpen, ShieldCheck, Printer } from 'lucide-react';

interface NavbarProps {
  settings: SchoolSettings;
  activeExam: Exam;
  onToggleMobileMenu: () => void;
  onOpenGuide: () => void;
  onOpenBulkAdmitCards: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  settings,
  activeExam,
  onToggleMobileMenu,
  onOpenGuide,
  onOpenBulkAdmitCards,
}) => {
  const { currentUser, isDemoAdmin, logout } = useAuth();

  return (
    <header className="bg-blue-950 text-white border-b border-blue-900 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Left: Mobile hamburger & College Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 text-slate-300 hover:text-white hover:bg-blue-900 rounded-lg cursor-pointer"
            title="Toggle Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white p-0.5 shadow-sm flex items-center justify-center flex-shrink-0">
              {settings.logoUrl ? (
                <img
                  src={settings.logoUrl}
                  alt="School Logo"
                  className="w-full h-full object-contain"
                />
              ) : (
                <span className="text-xs font-bold text-blue-950">RSKIC</span>
              )}
            </div>

            <div className="hidden sm:block">
              <div className="text-sm font-extrabold text-white tracking-wide uppercase leading-tight truncate max-w-sm">
                {settings.schoolName || 'RAJKUMAR SITARAM KISHAN INTER COLLEGE'}
              </div>
              <div className="text-[10px] text-amber-300 font-devanagari font-bold flex items-center gap-2">
                <span>राज कुमार सीताराम इण्टर कालेज, गोण्डा</span>
                <span className="text-blue-400">•</span>
                <span className="text-blue-200 uppercase font-sans">
                  {activeExam.session || '2026-27'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Quick actions & User profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onOpenBulkAdmitCards}
            className="hidden md:flex px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-blue-950 text-xs font-bold rounded-lg items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Bulk Print</span>
          </button>

          <button
            onClick={onOpenGuide}
            className="px-2.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-blue-100 text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors border border-blue-800"
            title="Admin System Guide"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Admin Guide</span>
          </button>

          {/* User Badge */}
          <div className="flex items-center gap-2 pl-2 border-l border-blue-900">
            <div className="w-8 h-8 rounded-full bg-blue-900 border border-blue-700 flex items-center justify-center text-xs font-bold text-amber-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="hidden lg:block text-left">
              <div className="text-xs font-bold text-white leading-tight">
                {isDemoAdmin ? 'Admin (Demo)' : currentUser?.displayName || 'College Admin'}
              </div>
              <div className="text-[10px] text-blue-300 leading-tight">
                {isDemoAdmin ? 'Super Admin' : currentUser?.email || 'admin@rskic.org'}
              </div>
            </div>

            {/* Logout */}
            <button
              onClick={logout}
              className="p-1.5 text-slate-300 hover:text-red-400 hover:bg-blue-900 rounded-lg cursor-pointer transition-colors ml-1"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </header>
  );
};
