import React from 'react';
import {
  LayoutDashboard,
  Users,
  Calendar,
  Clock,
  Printer,
  Settings,
  BookOpen,
  FileSpreadsheet,
  X,
  ExternalLink,
} from 'lucide-react';

interface SidebarProps {
  currentTab: 'dashboard' | 'students' | 'exams' | 'timetable' | 'settings';
  onSelectTab: (tab: 'dashboard' | 'students' | 'exams' | 'timetable' | 'settings') => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  onOpenBulkAdmitCards: () => void;
  onOpenExcelImport: () => void;
  onOpenGuide: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isMobileOpen,
  onCloseMobile,
  onOpenBulkAdmitCards,
  onOpenExcelImport,
  onOpenGuide,
}) => {
  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'students',
      label: 'Students & Admit Cards',
      icon: Users,
    },
    {
      id: 'exams',
      label: 'Exam Sessions',
      icon: Calendar,
    },
    {
      id: 'timetable',
      label: 'Timetable Management',
      icon: Clock,
    },
    {
      id: 'settings',
      label: 'School & Logo Settings',
      icon: Settings,
    },
  ] as const;

  const sidebarContent = (
    <div className="flex flex-col h-full justify-between p-4 bg-white border-r border-slate-200">
      <div className="space-y-6">
        {/* Navigation list */}
        <div>
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">
            Main Menu
          </div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectTab(item.id);
                    onCloseMobile();
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer text-left ${
                    isActive
                      ? 'bg-blue-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-blue-900 hover:bg-blue-50/60'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-500'}`}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Quick Operations */}
        <div>
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">
            Operations
          </div>
          <div className="space-y-1.5">
            <button
              onClick={() => {
                onOpenBulkAdmitCards();
                onCloseMobile();
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-blue-950 bg-amber-50 hover:bg-amber-100 border border-amber-300 transition-colors cursor-pointer text-left"
            >
              <Printer className="w-4 h-4 text-amber-700" />
              <span>Bulk Admit Cards</span>
            </button>

            <button
              onClick={() => {
                onOpenExcelImport();
                onCloseMobile();
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-emerald-950 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 transition-colors cursor-pointer text-left"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              <span>Bulk Excel Import</span>
            </button>
          </div>
        </div>
      </div>

      {/* College Info footer card */}
      <div className="pt-4 border-t border-slate-200 space-y-2">
        <button
          onClick={() => {
            onOpenGuide();
            onCloseMobile();
          }}
          className="w-full py-2 px-3 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-between cursor-pointer"
        >
          <span className="flex items-center gap-2">
            <BookOpen className="w-3.5 h-3.5 text-blue-800" />
            <span>Admin Guide (10 Steps)</span>
          </span>
          <span className="text-[10px] font-bold bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded">
            Help
          </span>
        </button>

        <div className="p-3 bg-blue-950 text-white rounded-xl text-[10px] space-y-1">
          <div className="font-extrabold text-amber-400">RSKIC MANAGEMENT</div>
          <p className="text-slate-300 leading-tight">
            Katra Road, Bamdera, Balpur, Gonda, U.P.
          </p>
          <div className="text-[9px] text-blue-300 pt-1">
            Status: Active & Connected
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 flex-shrink-0 sticky top-16 h-[calc(100vh-4rem)]">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          {/* Backdrop */}
          <div
            onClick={onCloseMobile}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
          />

          {/* Drawer content */}
          <div className="fixed inset-y-0 left-0 max-w-xs w-full bg-white z-50 shadow-2xl flex flex-col">
            <div className="p-4 bg-blue-950 text-white flex items-center justify-between">
              <span className="font-bold text-sm">RSKIC Management</span>
              <button
                onClick={onCloseMobile}
                className="p-1 rounded text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">{sidebarContent}</div>
          </div>
        </div>
      )}
    </>
  );
};
