import React from 'react';
import { X, BookOpen, CheckCircle2, ChevronRight, Terminal, Cloud, Shield, FileSpreadsheet, Printer } from 'lucide-react';

interface InstructionsGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstructionsGuideModal: React.FC<InstructionsGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const steps = [
    {
      num: 1,
      title: 'Running the Project Locally',
      desc: 'The project is powered by React + TypeScript + Vite. Run `npm install` to install dependencies and `npm run dev` to launch the dev server on port 3000.',
    },
    {
      num: 2,
      title: 'Configuring Firebase & Firestore Database',
      desc: 'Firebase is connected via firebase-applet-config.json. Firestore collections (`students`, `exams`, `timetables`, `schoolSettings`, `activityLogs`, `admins`) are backed by hardened firestore.rules deployed on the cloud with local offline cache fallback.',
    },
    {
      num: 3,
      title: 'Creating the First Admin Account',
      desc: 'Use Google Sign-In with your administrator Google email (e.g., thegondaminivlog1@gmail.com) or use standard email credentials. You can also use Instant Demo Admin access for immediate administrative control.',
    },
    {
      num: 4,
      title: 'Uploading Official School Logo, Stamp & Signatures',
      desc: 'Navigate to "School & Logo Settings". Upload the college circular seal/logo, principal signature (Mr. P.K. Mishra), and official school stamp. They automatically embed directly into all generated admit cards.',
    },
    {
      num: 5,
      title: 'Uploading Student Excel File',
      desc: 'Click "Import Excel" in the top bar or Students page. Click "Download Excel Template" to get the exact .xlsx format. Populate with students, upload the file, review the live validation preview, and click "Import Valid Records".',
    },
    {
      num: 6,
      title: 'Creating & Activating an Examination',
      desc: 'Go to "Exam Sessions". Edit the default "Half Yearly Examination 2026-27" or create a new session (e.g., Annual, Pre-Board). Set Exam Centre, Session Year, Default Timing (10:30 AM - 01:00 PM), and Reporting Time.',
    },
    {
      num: 7,
      title: 'Adding & Editing Timetable (Schedule)',
      desc: 'Go to "Timetable Management". View the exact master schedule matrix (Classes 6-12, dates 12/10/2026 to 24/10/2026 as per official college notice). Click any cell or "+ Add Timetable Entry" to adjust subjects or timings.',
    },
    {
      num: 8,
      title: 'Generating an Individual Admit Card',
      desc: 'Under "Students & Admit Cards", find the student using global search. Click "Admit Card". You can preview the exact board-format admit card, click "Print" for direct printing, or click "Generate PDF" for an A4 PDF download.',
    },
    {
      num: 9,
      title: 'Generating Bulk Admit Cards in One Click',
      desc: 'Click "Bulk Admit Cards" in the header or sidebar. Select "All Classes" or pick a specific class (e.g. Class 10 or Class 8). Click "Download Bulk PDF" or "Print All" to produce high-resolution, multi-page printouts with automatic page breaks.',
    },
    {
      num: 10,
      title: 'Deploying the Website Online',
      desc: 'Build the production bundle with `npm run build`. The resulting `dist` folder can be hosted anywhere (Cloud Run, Firebase Hosting, Vercel, Netlify). Ensure environment variables and firebase-applet-config.json are included.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="px-6 py-4 bg-blue-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-800 rounded-lg text-amber-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">
                RSKIC Admin Operations & Deployment Guide
              </h3>
              <p className="text-xs text-blue-200">
                Complete 10-step handbook for operating the school admit card system
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-blue-900 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-950 leading-relaxed">
            <strong>Welcome, College Administrator!</strong> This application has been custom-crafted for{' '}
            <strong>Rajkumar Sitaram Kishan Inter College, Bamdera Balpur, Gonda</strong>. Follow this step-by-step
            guide to configure exams, import records, and distribute admit cards.
          </div>

          <div className="space-y-3">
            {steps.map((st) => (
              <div
                key={st.num}
                className="p-4 rounded-xl border border-slate-200 bg-white hover:border-blue-300 hover:bg-slate-50/50 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-full bg-blue-900 text-amber-300 font-extrabold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                    {st.num}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-sm text-slate-900">{st.title}</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">{st.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold bg-blue-950 hover:bg-blue-900 text-white rounded-lg cursor-pointer"
          >
            Close Guide
          </button>
        </div>

      </div>
    </div>
  );
};
