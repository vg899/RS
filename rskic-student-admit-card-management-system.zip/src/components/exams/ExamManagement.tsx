import React, { useState } from 'react';
import { Exam } from '../../types';
import { Calendar, Plus, Edit, Trash2, CheckCircle2, Clock, MapPin, Award } from 'lucide-react';

interface ExamManagementProps {
  exams: Exam[];
  activeExamId: string;
  onSelectActiveExam: (examId: string) => void;
  onSaveExam: (exam: Exam) => Promise<void>;
  onDeleteExam: (examId: string) => Promise<void>;
}

export const ExamManagement: React.FC<ExamManagementProps> = ({
  exams,
  activeExamId,
  onSelectActiveExam,
  onSaveExam,
  onDeleteExam,
}) => {
  const [editingExam, setEditingExam] = useState<Exam | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleOpenAdd = () => {
    setEditingExam({
      id: `exam-${Date.now()}`,
      examName: '',
      session: '2026-27',
      centre: 'RAJKUMAR SITARAM KISHAN INTER COLLEGE, BAMDERA BALPUR - GONDA',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 12 * 86400000).toISOString().split('T')[0],
      defaultExamTime: '10:30 AM - 01:00 PM',
      reportingTime: '10:00 AM',
      instructions: '1. सभी विद्यार्थी निर्धारित समय पर उपस्थित हों। 2. अनुशासन अनिवार्य है। 3. बकाया शुल्क जमा करें।',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (exam: Exam) => {
    setEditingExam({ ...exam });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExam || !editingExam.examName.trim()) return;

    try {
      setSaving(true);
      await onSaveExam(editingExam);
      setIsModalOpen(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-blue-950 flex items-center gap-2">
            <span>Examination Management</span>
            <span className="text-xs bg-amber-100 text-amber-900 font-extrabold px-2.5 py-0.5 rounded-full">
              {exams.length} Configured
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure examination sessions, centres, reporting times and academic terms
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          <span>+ Create New Exam</span>
        </button>
      </div>

      {/* Cards list */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {exams.map((exam) => {
          const isActive = exam.id === activeExamId;
          return (
            <div
              key={exam.id}
              className={`rounded-xl border p-5 transition-all flex flex-col justify-between ${
                isActive
                  ? 'bg-blue-50/70 border-blue-500 shadow-md ring-2 ring-blue-500/20'
                  : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-blue-100 text-blue-900">
                      SESSION {exam.session}
                    </span>
                    <h3 className="font-extrabold text-blue-950 text-base mt-1.5 leading-snug">
                      {exam.examName}
                    </h3>
                  </div>

                  {isActive ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Active for Admit Cards
                    </span>
                  ) : (
                    <button
                      onClick={() => onSelectActiveExam(exam.id)}
                      className="text-[11px] font-semibold text-slate-600 hover:text-blue-900 bg-white border border-slate-300 px-2 py-0.5 rounded hover:bg-slate-50 cursor-pointer"
                    >
                      Set Active
                    </button>
                  )}
                </div>

                <div className="space-y-2 mt-4 text-xs text-slate-600">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <span className="font-medium truncate">{exam.centre}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <span>
                      <strong>Timing:</strong> {exam.defaultExamTime} (Reporting: {exam.reportingTime})
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <span>
                      <strong>Dates:</strong> {exam.startDate} to {exam.endDate}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-200/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Last updated: {new Date(exam.updatedAt || '').toLocaleDateString('en-GB')}
                </span>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(exam)}
                    className="p-1.5 text-blue-900 hover:bg-blue-100 rounded-md cursor-pointer transition-colors"
                    title="Edit Exam"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  {exams.length > 1 && (
                    <button
                      onClick={() => onDeleteExam(exam.id)}
                      className="p-1.5 text-red-600 hover:bg-red-50 rounded-md cursor-pointer transition-colors"
                      title="Delete Exam"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Exam Modal */}
      {isModalOpen && editingExam && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="px-6 py-4 bg-blue-950 text-white flex items-center justify-between">
              <h3 className="font-bold text-base">
                {editingExam.id ? 'Configure Examination' : 'Create Examination'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-300 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Exam Title (e.g. Half Yearly Examination 2026-27):
                </label>
                <input
                  type="text"
                  required
                  value={editingExam.examName}
                  onChange={(e) => setEditingExam({ ...editingExam, examName: e.target.value })}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Academic Session:
                  </label>
                  <input
                    type="text"
                    required
                    value={editingExam.session}
                    onChange={(e) => setEditingExam({ ...editingExam, session: e.target.value })}
                    placeholder="2026-27"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Reporting Time:
                  </label>
                  <input
                    type="text"
                    required
                    value={editingExam.reportingTime}
                    onChange={(e) => setEditingExam({ ...editingExam, reportingTime: e.target.value })}
                    placeholder="10:00 AM"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Default Exam Timing:
                  </label>
                  <input
                    type="text"
                    required
                    value={editingExam.defaultExamTime}
                    onChange={(e) =>
                      setEditingExam({ ...editingExam, defaultExamTime: e.target.value })
                    }
                    placeholder="10:30 AM - 01:00 PM"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Exam Dates Range:
                  </label>
                  <input
                    type="text"
                    value={`${editingExam.startDate} to ${editingExam.endDate}`}
                    onChange={(e) => {
                      const parts = e.target.value.split(' to ');
                      setEditingExam({
                        ...editingExam,
                        startDate: parts[0] || '',
                        endDate: parts[1] || '',
                      });
                    }}
                    placeholder="12/10/2026 to 24/10/2026"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Examination Centre:
                </label>
                <input
                  type="text"
                  required
                  value={editingExam.centre}
                  onChange={(e) => setEditingExam({ ...editingExam, centre: e.target.value })}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 text-xs font-bold bg-blue-900 hover:bg-blue-800 text-white rounded-lg cursor-pointer"
                >
                  {saving ? 'Saving...' : 'Save Exam'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
