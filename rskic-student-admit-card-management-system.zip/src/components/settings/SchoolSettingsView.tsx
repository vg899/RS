import React, { useState } from 'react';
import { SchoolSettings } from '../../types';
import {
  DEFAULT_SCHOOL_LOGO,
  DEFAULT_PRINCIPAL_SIGNATURE,
  DEFAULT_SCHOOL_STAMP,
  DEFAULT_SCHOOL_SETTINGS,
} from '../../firebase/defaultData';
import {
  Building2,
  Upload,
  RotateCcw,
  CheckCircle2,
  Image as ImageIcon,
  FileCheck,
  Plus,
  Trash2,
} from 'lucide-react';

interface SchoolSettingsViewProps {
  settings: SchoolSettings;
  onSaveSettings: (settings: SchoolSettings) => Promise<void>;
}

export const SchoolSettingsView: React.FC<SchoolSettingsViewProps> = ({
  settings,
  onSaveSettings,
}) => {
  const [formData, setFormData] = useState<SchoolSettings>({ ...settings });
  const [saving, setSaving] = useState(false);
  const [successToast, setSuccessToast] = useState(false);

  // File to base64 helper
  const handleImageUpload = (
    field: 'logoUrl' | 'principalSignature' | 'classTeacherSignature' | 'schoolStamp',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setFormData((prev) => ({ ...prev, [field]: dataUrl }));
    };
    reader.readAsDataURL(file);
  };

  const handleAddInstruction = () => {
    setFormData((prev) => ({
      ...prev,
      instructions: [...prev.instructions, ''],
    }));
  };

  const handleUpdateInstruction = (index: number, val: string) => {
    const updated = [...formData.instructions];
    updated[index] = val;
    setFormData((prev) => ({ ...prev, instructions: updated }));
  };

  const handleRemoveInstruction = (index: number) => {
    const updated = formData.instructions.filter((_, i) => i !== index);
    setFormData((prev) => ({ ...prev, instructions: updated }));
  };

  const handleResetToDefault = () => {
    if (window.confirm('Reset all school branding, logo, stamp, and instructions to official defaults?')) {
      setFormData({ ...DEFAULT_SCHOOL_SETTINGS });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await onSaveSettings(formData);
      setSuccessToast(true);
      setTimeout(() => setSuccessToast(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-blue-950 flex items-center gap-2">
            <span>School Settings & Branding</span>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-extrabold px-2.5 py-0.5 rounded-full">
              Official Profile
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure school name, address, seals, stamps, principal signatures and admit card notices
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="px-3.5 py-2 text-xs font-semibold bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Reset Defaults</span>
          </button>
        </div>
      </div>

      {successToast && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs rounded-xl font-bold flex items-center gap-2 shadow-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>School settings updated successfully! All future admit cards will reflect these changes.</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* SECTION 1: School Identity */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 space-y-4">
          <h3 className="text-sm font-bold text-blue-950 border-b border-slate-200 pb-2 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-800" />
            <span>School Information</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                School Name (English):
              </label>
              <input
                type="text"
                required
                value={formData.schoolName}
                onChange={(e) => setFormData({ ...formData, schoolName: e.target.value })}
                className="w-full text-xs font-bold px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                विद्यालय का नाम (Hindi / Devanagari):
              </label>
              <input
                type="text"
                value={formData.hindiSchoolName || ''}
                onChange={(e) => setFormData({ ...formData, hindiSchoolName: e.target.value })}
                className="w-full text-xs font-bold px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600 font-devanagari"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                College Address (Admit Card Header):
              </label>
              <input
                type="text"
                required
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Contact Phone:</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">School Email:</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">College Website:</label>
              <input
                type="text"
                value={formData.website}
                onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Principal Name (प्रधानाचार्य):
              </label>
              <input
                type="text"
                required
                value={formData.principalName}
                onChange={(e) => setFormData({ ...formData, principalName: e.target.value })}
                className="w-full text-xs font-bold px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600"
              />
            </div>
          </div>
        </div>

        {/* SECTION 2: School Logo, Stamp & Signatures */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 space-y-4">
          <h3 className="text-sm font-bold text-blue-950 border-b border-slate-200 pb-2 flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-blue-800" />
            <span>Logo, Official Stamp & Signatures</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* School Logo */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60 flex flex-col items-center justify-between text-center">
              <span className="text-xs font-bold text-slate-800 mb-2">School Logo / Seal</span>
              <div className="w-24 h-24 rounded-lg bg-white border border-slate-300 p-1 flex items-center justify-center overflow-hidden mb-3 shadow-2xs">
                {formData.logoUrl ? (
                  <img src={formData.logoUrl} alt="Logo" className="max-h-full max-w-full object-contain" />
                ) : (
                  <span className="text-[10px] text-slate-400 font-semibold">No Logo</span>
                )}
              </div>
              <label className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-[11px] font-bold rounded-lg cursor-pointer transition-colors shadow-xs flex items-center gap-1">
                <Upload className="w-3 h-3 text-amber-400" />
                <span>Upload Logo</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload('logoUrl', e)}
                  className="hidden"
                />
              </label>
            </div>

            {/* Principal Signature */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60 flex flex-col items-center justify-between text-center">
              <span className="text-xs font-bold text-slate-800 mb-2">Principal Signature</span>
              <div className="w-36 h-24 rounded-lg bg-white border border-slate-300 p-1 flex items-center justify-center overflow-hidden mb-3 shadow-2xs">
                {formData.principalSignature ? (
                  <img
                    src={formData.principalSignature}
                    alt="Principal Sign"
                    className="max-h-full max-w-full object-contain"
                  />
                ) : (
                  <span className="text-[10px] text-slate-400 font-semibold">No Signature</span>
                )}
              </div>
              <label className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-[11px] font-bold rounded-lg cursor-pointer transition-colors shadow-xs flex items-center gap-1">
                <Upload className="w-3 h-3 text-amber-400" />
                <span>Upload Signature</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload('principalSignature', e)}
                  className="hidden"
                />
              </label>
            </div>

            {/* Class Teacher Signature */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60 flex flex-col items-center justify-between text-center">
              <span className="text-xs font-bold text-slate-800 mb-2">Class Teacher Signature</span>
              <div className="w-36 h-24 rounded-lg bg-white border border-slate-300 p-1 flex items-center justify-center overflow-hidden mb-3 shadow-2xs">
                {formData.classTeacherSignature ? (
                  <img
                    src={formData.classTeacherSignature}
                    alt="Teacher Sign"
                    className="max-h-full max-w-full object-contain"
                  />
                ) : (
                  <span className="text-[10px] text-slate-400 font-semibold">Blank (Leave for Pen)</span>
                )}
              </div>
              <label className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-bold rounded-lg cursor-pointer transition-colors shadow-xs flex items-center gap-1">
                <Upload className="w-3 h-3 text-amber-400" />
                <span>Upload Signature</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload('classTeacherSignature', e)}
                  className="hidden"
                />
              </label>
            </div>

            {/* School Stamp */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60 flex flex-col items-center justify-between text-center">
              <span className="text-xs font-bold text-slate-800 mb-2">Official College Stamp</span>
              <div className="w-24 h-24 rounded-lg bg-white border border-slate-300 p-1 flex items-center justify-center overflow-hidden mb-3 shadow-2xs">
                {formData.schoolStamp ? (
                  <img src={formData.schoolStamp} alt="Stamp" className="max-h-full max-w-full object-contain" />
                ) : (
                  <span className="text-[10px] text-slate-400 font-semibold">No Stamp</span>
                )}
              </div>
              <label className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-[11px] font-bold rounded-lg cursor-pointer transition-colors shadow-xs flex items-center gap-1">
                <Upload className="w-3 h-3 text-amber-400" />
                <span>Upload Stamp</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload('schoolStamp', e)}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>

        {/* SECTION 3: Important Instructions */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div>
              <h3 className="text-sm font-bold text-blue-950 flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-blue-800" />
                <span>Admit Card Instructions (महत्वपूर्ण निर्देश - हिन्दी)</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Printed verbatim on each admit card's footer
              </p>
            </div>
            <button
              type="button"
              onClick={handleAddInstruction}
              className="px-2.5 py-1 text-xs font-bold text-blue-900 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>Add Line</span>
            </button>
          </div>

          <div className="space-y-2">
            {formData.instructions.map((inst, index) => (
              <div key={index} className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500 w-6 text-right font-mono">
                  {index + 1}.
                </span>
                <input
                  type="text"
                  value={inst}
                  onChange={(e) => handleUpdateInstruction(index, e.target.value)}
                  className="flex-1 text-xs font-medium px-3 py-2 rounded-lg border border-slate-300 focus:outline-blue-600 font-devanagari text-slate-900"
                />
                <button
                  type="button"
                  onClick={() => handleRemoveInstruction(index)}
                  className="p-2 text-slate-400 hover:text-red-600 rounded cursor-pointer"
                  title="Remove Instruction"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 bg-blue-950 hover:bg-blue-900 text-white rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer shadow-sm transition-colors"
          >
            <CheckCircle2 className="w-4 h-4 text-amber-400" />
            <span>{saving ? 'Saving Settings...' : 'Save School Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
