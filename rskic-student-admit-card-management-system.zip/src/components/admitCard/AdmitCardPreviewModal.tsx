import React, { useRef, useState } from 'react';
import { Student, Exam, TimetableEntry, SchoolSettings } from '../../types';
import { AdmitCardTemplate } from './AdmitCardTemplate';
import { pdfService } from '../../services/pdfService';
import { Printer, Download, X, Edit3, Loader2, Check } from 'lucide-react';

interface AdmitCardPreviewModalProps {
  student: Student;
  exam: Exam;
  timetables: TimetableEntry[];
  settings: SchoolSettings;
  isOpen: boolean;
  onClose: () => void;
  onEditStudent?: (student: Student) => void;
}

export const AdmitCardPreviewModal: React.FC<AdmitCardPreviewModalProps> = ({
  student,
  exam,
  timetables,
  settings,
  isOpen,
  onClose,
  onEditStudent,
}) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handleDownloadPdf = async () => {
    if (!cardRef.current) return;
    try {
      setDownloading(true);
      const filename = `RSKIC_AdmitCard_${student.studentName.replace(/\s+/g, '_')}_Class${student.class}_Roll${student.rollNumber}.pdf`;
      await pdfService.generateSingleAdmitCardPdf(cardRef.current, filename);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (error) {
      alert('Failed to generate PDF. You can also use the "Print" button to save as PDF.');
    } finally {
      setDownloading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 print:p-0 print:bg-white print:fixed print:inset-0">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[96vh] flex flex-col overflow-hidden border border-slate-200 print:shadow-none print:border-none print:max-h-none print:w-full print:rounded-none">
        
        {/* Modal Header (Hidden on Print) */}
        <div className="px-5 py-3.5 bg-blue-950 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-800 flex items-center justify-center font-bold text-amber-400">
              AC
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">Admit Card Preview</h3>
              <p className="text-xs text-blue-200">
                {student.studentName} • Class {student.class}-{student.section} • Roll No: {student.rollNumber}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onEditStudent && (
              <button
                onClick={() => {
                  onClose();
                  onEditStudent(student);
                }}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            )}

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-semibold bg-blue-700 hover:bg-blue-600 text-white rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

            <button
              onClick={handleDownloadPdf}
              disabled={downloading}
              className="px-3 py-1.5 text-xs font-semibold bg-amber-500 hover:bg-amber-600 text-blue-950 font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 shadow-xs"
            >
              {downloading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Generating...</span>
                </>
              ) : downloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-green-900" />
                  <span>Downloaded!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>Generate PDF</span>
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-blue-900 rounded-lg transition-colors cursor-pointer ml-1"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body / Scrollable Canvas */}
        <div className="p-4 overflow-y-auto bg-slate-100/70 flex-1 flex justify-center print:p-0 print:bg-white print:overflow-visible">
          <div ref={cardRef} className="print:m-0 print:w-full">
            <AdmitCardTemplate
              student={student}
              exam={exam}
              timetables={timetables}
              settings={settings}
            />
          </div>
        </div>

        {/* Modal Footer helper */}
        <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between print:hidden">
          <span>
            💡 Pro-tip: For best print results, select <strong>A4</strong> paper and enable <strong>Background graphics</strong> in print options.
          </span>
          <button
            onClick={onClose}
            className="px-3 py-1 text-slate-700 font-medium hover:bg-slate-200 rounded cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
