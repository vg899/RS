import React, { useState, useRef } from 'react';
import { Student, Exam, TimetableEntry, SchoolSettings, ALL_CLASSES, ALL_SECTIONS, StudentClass } from '../../types';
import { AdmitCardTemplate } from './AdmitCardTemplate';
import { pdfService } from '../../services/pdfService';
import { Printer, Download, X, Users, CheckSquare, Square, Loader2, Sparkles } from 'lucide-react';

interface BulkAdmitCardModalProps {
  students: Student[];
  exam: Exam;
  timetables: TimetableEntry[];
  settings: SchoolSettings;
  isOpen: boolean;
  onClose: () => void;
  onLogActivity?: (msg: string) => void;
}

export const BulkAdmitCardModal: React.FC<BulkAdmitCardModalProps> = ({
  students,
  exam,
  timetables,
  settings,
  isOpen,
  onClose,
  onLogActivity,
}) => {
  const [selectedClass, setSelectedClass] = useState<string>('ALL');
  const [selectedSection, setSelectedSection] = useState<string>('ALL');
  const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(() => {
    return new Set(students.map((s) => s.id));
  });

  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const [isDone, setIsDone] = useState(false);
  const bulkCardsContainerRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  // Filter students based on filter controls
  const filteredStudents = students.filter((s) => {
    if (selectedClass !== 'ALL' && s.class !== selectedClass) return false;
    if (selectedSection !== 'ALL' && s.section !== selectedSection) return false;
    return true;
  });

  const handleSelectAllFiltered = () => {
    const updated = new Set(selectedStudentIds);
    filteredStudents.forEach((s) => updated.add(s.id));
    setSelectedStudentIds(updated);
  };

  const handleDeselectAllFiltered = () => {
    const updated = new Set(selectedStudentIds);
    filteredStudents.forEach((s) => updated.delete(s.id));
    setSelectedStudentIds(updated);
  };

  const toggleStudent = (id: string) => {
    const next = new Set(selectedStudentIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedStudentIds(next);
  };

  const targetStudents = filteredStudents.filter((s) => selectedStudentIds.has(s.id));

  // Generate Multi-page PDF for all chosen students
  const handleGenerateBulkPdf = async () => {
    if (!bulkCardsContainerRef.current || targetStudents.length === 0) return;
    try {
      setGenerating(true);
      setIsDone(false);
      setProgress({ current: 0, total: targetStudents.length });

      const cardElements = Array.from(
        bulkCardsContainerRef.current.querySelectorAll<HTMLElement>('.bulk-card-item')
      );

      const filename = `RSKIC_Bulk_AdmitCards_${selectedClass !== 'ALL' ? 'Class_' + selectedClass : 'All'}_${Date.now()}.pdf`;

      await pdfService.generateBulkAdmitCardsPdf(
        cardElements,
        filename,
        (current, total) => {
          setProgress({ current, total });
        }
      );

      setIsDone(true);
      if (onLogActivity) {
        onLogActivity(`Generated bulk admit cards for ${targetStudents.length} students`);
      }
    } catch (error) {
      alert('Bulk generation encountered an issue. For large batches, you can also use "Print All" to save as PDF via system print.');
    } finally {
      setGenerating(false);
    }
  };

  const handleBatchPrint = () => {
    window.print();
    if (onLogActivity) {
      onLogActivity(`Sent ${targetStudents.length} admit cards to printer`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 print:p-0 print:bg-white print:fixed print:inset-0">
      <div className="bg-white rounded-xl shadow-2xl max-w-5xl w-full max-h-[95vh] flex flex-col overflow-hidden border border-slate-200 print:shadow-none print:border-none print:max-h-none print:w-full print:rounded-none">
        
        {/* Header */}
        <div className="px-6 py-4 bg-blue-950 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-800 rounded-lg text-amber-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">Bulk Admit Card Generator</h3>
              <p className="text-xs text-blue-200">
                Generate or print admit cards in batch for classes, sections, or selected students
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-blue-900 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters and Controls (Hidden on Print) */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 print:hidden space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Filter by Class:</label>
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="w-full text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white focus:outline-blue-600"
              >
                <option value="ALL">All Classes ({students.length} students)</option>
                {ALL_CLASSES.map((cls) => {
                  const count = students.filter((s) => s.class === cls).length;
                  return (
                    <option key={cls} value={cls}>
                      Class {cls} ({count})
                    </option>
                  );
                })}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Filter by Section:</label>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
                className="w-full text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white focus:outline-blue-600"
              >
                <option value="ALL">All Sections</option>
                {ALL_SECTIONS.map((sec) => (
                  <option key={sec} value={sec}>
                    Section {sec}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2 flex items-end justify-between gap-2">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleSelectAllFiltered}
                  className="px-2.5 py-1.5 text-xs font-semibold bg-white border border-slate-300 hover:bg-slate-100 rounded-md flex items-center gap-1 text-slate-700 cursor-pointer"
                >
                  <CheckSquare className="w-3.5 h-3.5 text-blue-600" />
                  Select All Filtered
                </button>
                <button
                  type="button"
                  onClick={handleDeselectAllFiltered}
                  className="px-2.5 py-1.5 text-xs font-semibold bg-white border border-slate-300 hover:bg-slate-100 rounded-md flex items-center gap-1 text-slate-700 cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5 text-slate-400" />
                  Deselect All
                </button>
              </div>

              <div className="text-right">
                <span className="text-xs font-bold text-blue-900 bg-blue-100 px-2 py-1 rounded">
                  {targetStudents.length} Selected
                </span>
              </div>
            </div>
          </div>

          {/* Student selection chips table */}
          <div className="max-h-28 overflow-y-auto border border-slate-200 rounded-lg p-2 bg-white flex flex-wrap gap-1.5">
            {filteredStudents.map((s) => {
              const isSelected = selectedStudentIds.has(s.id);
              return (
                <button
                  key={s.id}
                  onClick={() => toggleStudent(s.id)}
                  type="button"
                  className={`px-2 py-0.5 rounded text-xs font-medium border flex items-center gap-1.5 transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-blue-50 border-blue-400 text-blue-950 font-semibold'
                      : 'bg-slate-50 border-slate-200 text-slate-500 line-through'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  <span>{s.studentName} (Cl-{s.class} Roll-{s.rollNumber})</span>
                </button>
              );
            })}
            {filteredStudents.length === 0 && (
              <span className="text-xs text-slate-400 italic p-1">No students match current filters.</span>
            )}
          </div>
        </div>

        {/* Progress bar when generating */}
        {generating && (
          <div className="p-4 bg-amber-50 border-b border-amber-200 print:hidden">
            <div className="flex items-center justify-between text-xs font-bold text-amber-900 mb-1">
              <span className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-amber-700" />
                Generating Bulk PDF...
              </span>
              <span>
                {progress.current} / {progress.total} Completed ({Math.round((progress.current / (progress.total || 1)) * 100)}%)
              </span>
            </div>
            <div className="w-full bg-amber-200 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-amber-600 h-2.5 rounded-full transition-all duration-300"
                style={{
                  width: `${(progress.current / (progress.total || 1)) * 100}%`,
                }}
              ></div>
            </div>
          </div>
        )}

        {/* Body Preview & Printable Canvas */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-100 flex flex-col items-center gap-6 print:p-0 print:bg-white print:overflow-visible">
          <div className="text-xs text-slate-500 font-medium mb-1 print:hidden flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-blue-700" />
            Showing preview of {targetStudents.length} Admit Cards. Scroll down to inspect individual cards.
          </div>

          <div ref={bulkCardsContainerRef} className="w-full flex flex-col items-center gap-8 print:gap-0">
            {targetStudents.map((s, index) => (
              <div
                key={s.id}
                className="bulk-card-item w-full flex justify-center print:page-break-after-always print:m-0"
                style={{
                  pageBreakAfter: 'always',
                  breakAfter: 'page',
                }}
              >
                <AdmitCardTemplate
                  id={`bulk-admit-card-${s.id}`}
                  student={s}
                  exam={exam}
                  timetables={timetables}
                  settings={settings}
                />
              </div>
            ))}

            {targetStudents.length === 0 && (
              <div className="py-16 text-center text-slate-400">
                <Users className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                <p className="font-semibold text-sm">No students selected.</p>
                <p className="text-xs">Adjust your class/section filter or check students above.</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions (Hidden on Print) */}
        <div className="px-6 py-3.5 bg-white border-t border-slate-200 flex items-center justify-between print:hidden">
          <div className="text-xs text-slate-600">
            Selected: <strong className="text-blue-900">{targetStudents.length}</strong> admit cards
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
            >
              Cancel
            </button>

            <button
              onClick={handleBatchPrint}
              disabled={targetStudents.length === 0 || generating}
              className="px-4 py-2 text-xs font-bold bg-blue-700 hover:bg-blue-600 text-white rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 shadow-xs"
            >
              <Printer className="w-4 h-4" />
              <span>Print All ({targetStudents.length})</span>
            </button>

            <button
              onClick={handleGenerateBulkPdf}
              disabled={targetStudents.length === 0 || generating}
              className="px-4 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-blue-950 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 shadow-xs"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Generating {progress.current}/{progress.total}...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download Bulk PDF ({targetStudents.length})</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
