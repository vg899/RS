import React from 'react';
import { Student, Exam, TimetableEntry, SchoolSettings } from '../../types';

interface AdmitCardTemplateProps {
  student: Student;
  exam: Exam;
  timetables: TimetableEntry[];
  settings: SchoolSettings;
  id?: string;
  className?: string;
}

// Helper to calculate weekday from DD/MM/YYYY or YYYY-MM-DD
function getDayName(dateStr: string): string {
  try {
    let d: Date;
    if (dateStr.includes('/')) {
      const parts = dateStr.split('/');
      if (parts.length === 3) {
        // DD/MM/YYYY
        d = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
      } else {
        d = new Date(dateStr);
      }
    } else {
      d = new Date(dateStr);
    }
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return isNaN(d.getTime()) ? '' : days[d.getDay()];
  } catch (e) {
    return '';
  }
}

export const AdmitCardTemplate: React.FC<AdmitCardTemplateProps> = ({
  student,
  exam,
  timetables,
  settings,
  id = 'printable-admit-card',
  className = '',
}) => {
  // Filter timetable strictly for this student's class
  const classTimetable = timetables
    .filter((t) => String(t.class).trim() === String(student.class).trim())
    .sort((a, b) => {
      // Sort by date if possible
      return a.date.localeCompare(b.date);
    });

  return (
    <div
      id={id}
      className={`admit-card-container bg-white text-slate-900 border-4 border-double border-blue-950 p-6 max-w-[800px] mx-auto shadow-md font-sans relative ${className}`}
      style={{
        boxSizing: 'border-box',
        minHeight: '1050px',
        backgroundColor: '#ffffff',
      }}
    >
      {/* Decorative inner frame */}
      <div className="border border-blue-900/40 p-4 h-full flex flex-col justify-between">
        
        {/* HEADER SECTION */}
        <div>
          <div className="flex items-center justify-between border-b-2 border-blue-950 pb-3 mb-3">
            {/* School Logo */}
            <div className="w-24 h-24 flex-shrink-0 flex items-center justify-center p-1">
              {settings.logoUrl ? (
                <img
                  src={settings.logoUrl}
                  alt="School Logo"
                  className="max-h-24 max-w-24 object-contain"
                />
              ) : (
                <div className="w-20 h-20 rounded-full border-2 border-blue-900 flex items-center justify-center text-xs font-bold text-blue-900">
                  LOGO
                </div>
              )}
            </div>

            {/* School Titles */}
            <div className="flex-1 text-center px-2">
              <h1 className="text-xl md:text-2xl font-extrabold text-blue-950 tracking-wide font-devanagari">
                {settings.hindiSchoolName || 'राज कुमार सीताराम इण्टर कालेज'}
              </h1>
              <h2 className="text-base md:text-lg font-bold text-blue-900 tracking-wider uppercase mt-0.5">
                {settings.schoolName || 'RAJKUMAR SITARAM KISHAN INTER COLLEGE'}
              </h2>
              <p className="text-[11px] font-semibold text-slate-700 uppercase mt-0.5">
                {settings.address || 'KATRA ROAD, BAMDERA, BALPUR, GONDA, UTTAR PRADESH'}
              </p>
              <div className="flex justify-center gap-4 text-[10px] text-slate-600 font-medium mt-1">
                {settings.phone && <span>📞 {settings.phone}</span>}
                {settings.email && <span>✉️ {settings.email}</span>}
                {settings.website && <span>🌐 {settings.website}</span>}
              </div>
            </div>

            {/* Top Right Mini Seal / Watermark placeholder */}
            <div className="w-24 flex flex-col items-center justify-center flex-shrink-0 text-center">
              <div className="border border-blue-900 bg-blue-50/60 rounded px-2 py-1 text-[10px] font-bold text-blue-900">
                U.P. BOARD AFFILIATED
              </div>
              <div className="text-[10px] text-slate-600 mt-1 font-semibold">
                SESSION {exam.session || '2026-27'}
              </div>
            </div>
          </div>

          {/* Exam Banner & Title */}
          <div className="text-center my-2">
            <div className="inline-block bg-blue-950 text-white font-extrabold text-sm md:text-base px-6 py-1 rounded tracking-wide uppercase shadow-sm">
              {exam.examName || 'HALF YEARLY EXAMINATION 2026-27'}
            </div>
            <div className="mt-1 flex items-center justify-center gap-3">
              <span className="h-[1.5px] w-12 bg-blue-900"></span>
              <span className="text-base font-black tracking-widest text-red-700 uppercase border-b-2 border-red-700 px-3">
                ADMIT CARD / प्रवेश पत्र
              </span>
              <span className="h-[1.5px] w-12 bg-blue-900"></span>
            </div>
          </div>

          {/* STUDENT DETAILS GRID & PHOTO */}
          <div className="mt-3 border-2 border-blue-950 rounded bg-slate-50/50 p-2 flex flex-col md:flex-row gap-3">
            {/* Student Info Table */}
            <div className="flex-1 overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <tbody>
                  <tr className="border-b border-slate-300">
                    <td className="py-1 px-2 font-bold text-slate-700 w-32">Admit Card No:</td>
                    <td className="py-1 px-2 font-black text-red-700 tracking-wider">
                      {student.admitCardNumber || 'RSKIC-2026-0001'}
                    </td>
                    <td className="py-1 px-2 font-bold text-slate-700 w-28">Roll Number:</td>
                    <td className="py-1 px-2 font-black text-blue-950 text-sm">
                      {student.rollNumber}
                    </td>
                  </tr>
                  <tr className="border-b border-slate-300">
                    <td className="py-1 px-2 font-bold text-slate-700">Student Name:</td>
                    <td className="py-1 px-2 font-extrabold text-slate-900 uppercase">
                      {student.studentName}
                    </td>
                    <td className="py-1 px-2 font-bold text-slate-700">Class & Sec:</td>
                    <td className="py-1 px-2 font-bold text-blue-950">
                      Class {student.class} - {student.section}
                    </td>
                  </tr>
                  <tr className="border-b border-slate-300">
                    <td className="py-1 px-2 font-bold text-slate-700">Father's Name:</td>
                    <td className="py-1 px-2 font-semibold text-slate-800 uppercase">
                      {student.fatherName}
                    </td>
                    <td className="py-1 px-2 font-bold text-slate-700">Date of Birth:</td>
                    <td className="py-1 px-2 font-semibold text-slate-800">
                      {student.dob || '—'}
                    </td>
                  </tr>
                  <tr className="border-b border-slate-300">
                    <td className="py-1 px-2 font-bold text-slate-700">Mother's Name:</td>
                    <td className="py-1 px-2 font-semibold text-slate-800 uppercase">
                      {student.motherName || '—'}
                    </td>
                    <td className="py-1 px-2 font-bold text-slate-700">Gender:</td>
                    <td className="py-1 px-2 font-semibold text-slate-800">
                      {student.gender}
                    </td>
                  </tr>
                  <tr className="border-b border-slate-300">
                    <td className="py-1 px-2 font-bold text-slate-700">Student ID / Adm No:</td>
                    <td className="py-1 px-2 font-semibold text-slate-800">
                      {student.studentId || student.admissionNumber || 'RSKIC-ST-N/A'}
                    </td>
                    <td className="py-1 px-2 font-bold text-slate-700">Exam Time:</td>
                    <td className="py-1 px-2 font-bold text-blue-950">
                      {exam.defaultExamTime || '10:30 AM - 01:00 PM'}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-1 px-2 font-bold text-slate-700">Examination Centre:</td>
                    <td colSpan={3} className="py-1 px-2 font-semibold text-slate-800">
                      {exam.centre || settings.schoolName}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Student Photo */}
            <div className="w-28 flex flex-col items-center justify-center flex-shrink-0">
              <div className="w-24 h-28 border-2 border-blue-950 rounded bg-white overflow-hidden shadow-sm flex items-center justify-center p-0.5">
                {student.photoUrl ? (
                  <img
                    src={student.photoUrl}
                    alt={student.studentName}
                    className="w-full h-full object-cover rounded-sm"
                  />
                ) : (
                  <div className="w-full h-full bg-slate-100 flex flex-col items-center justify-center text-slate-400 text-[10px] text-center p-1 border border-dashed border-slate-300">
                    <svg className="w-8 h-8 mb-1 text-slate-300" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                    </svg>
                    <span>PASSPORT PHOTO</span>
                  </div>
                )}
              </div>
              <span className="text-[9px] font-bold text-slate-600 mt-1 uppercase">
                Roll No: {student.rollNumber}
              </span>
            </div>
          </div>

          {/* CLASS EXAMINATION TIMETABLE */}
          <div className="mt-3">
            <div className="flex justify-between items-center bg-blue-950 text-white px-3 py-1 rounded-t text-xs font-bold">
              <span>EXAMINATION TIMETABLE (परीक्षा समय सारिणी) - CLASS {student.class}</span>
              <span className="text-[11px] font-normal">Reporting Time: {exam.reportingTime || '10:00 AM'}</span>
            </div>

            <table className="w-full text-xs border border-blue-950 text-center border-collapse">
              <thead>
                <tr className="bg-slate-100 text-blue-950 font-bold border-b border-blue-950">
                  <th className="py-1 px-1 border-r border-blue-950 w-10">S.No.</th>
                  <th className="py-1 px-2 border-r border-blue-950 w-24">Date (दिनांक)</th>
                  <th className="py-1 px-2 border-r border-blue-950 w-24">Day (दिन)</th>
                  <th className="py-1 px-2 border-r border-blue-950 text-left">Subject (विषय)</th>
                  <th className="py-1 px-2 border-r border-blue-950 w-36">Timing (समय)</th>
                  <th className="py-1 px-2 w-24">Invigilator Sign</th>
                </tr>
              </thead>
              <tbody>
                {classTimetable.length > 0 ? (
                  classTimetable.map((item, idx) => (
                    <tr
                      key={item.id || idx}
                      className={`border-b border-slate-300 text-[11px] ${
                        idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'
                      }`}
                    >
                      <td className="py-1 px-1 border-r border-slate-300 font-semibold">{idx + 1}</td>
                      <td className="py-1 px-2 border-r border-slate-300 font-bold text-blue-900">
                        {item.date}
                      </td>
                      <td className="py-1 px-2 border-r border-slate-300 text-slate-700">
                        {getDayName(item.date) || '—'}
                      </td>
                      <td className="py-1 px-2 border-r border-slate-300 text-left font-bold text-slate-900 font-devanagari">
                        {item.subject}
                      </td>
                      <td className="py-1 px-2 border-r border-slate-300 font-semibold text-slate-800">
                        {item.examTime || exam.defaultExamTime || '10:30 AM - 01:00 PM'}
                      </td>
                      <td className="py-1 px-2 border-slate-300"></td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-3 text-slate-500 italic">
                      No timetable scheduled yet for Class {student.class}. Please configure timetable in settings.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* IMPORTANT INSTRUCTIONS */}
          <div className="mt-3 border border-slate-400 rounded bg-slate-50/80 p-2">
            <h4 className="text-xs font-black text-red-800 uppercase tracking-wide border-b border-slate-300 pb-0.5 mb-1 flex items-center justify-between">
              <span>महत्वपूर्ण निर्देश (IMPORTANT INSTRUCTIONS):</span>
              <span className="text-[10px] font-normal lowercase text-slate-500">By Order (Principal) Mr. P.K. Mishra</span>
            </h4>
            <ol className="text-[11px] font-medium text-slate-800 list-decimal list-inside space-y-0.5 leading-snug font-devanagari">
              {settings.instructions && settings.instructions.length > 0 ? (
                settings.instructions.map((inst, index) => (
                  <li key={index} className="text-slate-900">
                    {inst}
                  </li>
                ))
              ) : (
                <>
                  <li>सभी विद्यार्थी निर्धारित समय पर परीक्षा केन्द्र पर उपस्थित हों।</li>
                  <li>परीक्षा के समय अनुशासन का पालन करना अनिवार्य है।</li>
                  <li>अनुपस्थित रहने पर पुनः परीक्षा नहीं होगी।</li>
                  <li>अपना समस्त बकाया एवं परीक्षा शुल्क जमा करें।</li>
                </>
              )}
            </ol>
          </div>
        </div>

        {/* SIGNATURES AND STAMP SECTION */}
        <div className="mt-4 pt-2 border-t-2 border-slate-300">
          <div className="grid grid-cols-3 items-end text-center">
            
            {/* Class Teacher Signature */}
            <div className="flex flex-col items-center justify-end h-20">
              {settings.classTeacherSignature && (
                <img
                  src={settings.classTeacherSignature}
                  alt="Teacher Sign"
                  className="max-h-12 object-contain mb-1"
                />
              )}
              <div className="w-40 border-t border-slate-700 pt-1 text-[11px] font-bold text-slate-800">
                Class Teacher Signature
                <div className="text-[9px] font-normal text-slate-600 font-devanagari">
                  (हस्ताक्षर कक्षाध्यापक)
                </div>
              </div>
            </div>

            {/* School Seal / Stamp */}
            <div className="flex flex-col items-center justify-end h-20">
              {settings.schoolStamp ? (
                <img
                  src={settings.schoolStamp}
                  alt="School Stamp"
                  className="max-h-16 object-contain"
                />
              ) : (
                <div className="w-16 h-16 rounded-full border border-dashed border-red-800 flex items-center justify-center text-[9px] text-red-800 font-bold">
                  SEAL / STAMP
                </div>
              )}
              <div className="text-[10px] font-bold text-slate-800 mt-1">
                School Stamp
                <div className="text-[9px] font-normal text-slate-600 font-devanagari">
                  (विद्यालय मुहर)
                </div>
              </div>
            </div>

            {/* Principal Signature */}
            <div className="flex flex-col items-center justify-end h-20">
              {settings.principalSignature ? (
                <img
                  src={settings.principalSignature}
                  alt="Principal Signature"
                  className="max-h-12 object-contain mb-1"
                />
              ) : (
                <div className="h-8"></div>
              )}
              <div className="w-40 border-t border-slate-700 pt-1 text-[11px] font-bold text-slate-800">
                Principal Signature
                <div className="text-[9px] font-semibold text-blue-900">
                  {settings.principalName || 'Mr. P.K. Mishra'}
                </div>
                <div className="text-[9px] font-normal text-slate-600 font-devanagari">
                  (हस्ताक्षर प्रधानाचार्य)
                </div>
              </div>
            </div>

          </div>

          {/* Footer print stamp */}
          <div className="mt-2 text-center text-[9px] text-slate-400 flex justify-between border-t border-slate-200 pt-1">
            <span>RSKIC Admit Card System • Bamdera Balpur Gonda</span>
            <span>Generated: {new Date().toLocaleDateString('en-GB')}</span>
            <span>Verify at College Office</span>
          </div>
        </div>

      </div>
    </div>
  );
};
