import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { dataService } from './services/dataService';
import { testConnection } from './firebase/config';
import {
  Student,
  Exam,
  TimetableEntry,
  SchoolSettings,
  ActivityLog,
} from './types';
import {
  DEFAULT_SCHOOL_SETTINGS,
  DEFAULT_EXAM,
  DEFAULT_TIMETABLES,
  SAMPLE_STUDENTS,
} from './firebase/defaultData';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardOverview } from './components/dashboard/DashboardOverview';
import { StudentList } from './components/students/StudentList';
import { ExamManagement } from './components/exams/ExamManagement';
import { TimetableManagement } from './components/timetable/TimetableManagement';
import { SchoolSettingsView } from './components/settings/SchoolSettingsView';
import { StudentFormModal } from './components/students/StudentFormModal';
import { ExcelImportModal } from './components/students/ExcelImportModal';
import { AdmitCardPreviewModal } from './components/admitCard/AdmitCardPreviewModal';
import { BulkAdmitCardModal } from './components/admitCard/BulkAdmitCardModal';
import { InstructionsGuideModal } from './components/layout/InstructionsGuideModal';
import { LoginView } from './components/auth/LoginView';
import { Loader2 } from 'lucide-react';

function MainAppContent() {
  const { currentUser, isDemoAdmin, loading: authLoading } = useAuth();

  // Primary State
  const [students, setStudents] = useState<Student[]>(SAMPLE_STUDENTS);
  const [exams, setExams] = useState<Exam[]>([DEFAULT_EXAM]);
  const [activeExamId, setActiveExamId] = useState<string>(DEFAULT_EXAM.id);
  const [timetables, setTimetables] = useState<TimetableEntry[]>(DEFAULT_TIMETABLES);
  const [settings, setSettings] = useState<SchoolSettings>(DEFAULT_SCHOOL_SETTINGS);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(true);

  // Active Navigation Tab
  const [currentTab, setCurrentTab] = useState<
    'dashboard' | 'students' | 'exams' | 'timetable' | 'settings'
  >('dashboard');

  // Modals
  const [isStudentFormOpen, setIsStudentFormOpen] = useState(false);
  const [studentToEdit, setStudentToEdit] = useState<Student | null>(null);
  const [isExcelImportOpen, setIsExcelImportOpen] = useState(false);
  const [isBulkAdmitCardsOpen, setIsBulkAdmitCardsOpen] = useState(false);
  const [isPreviewAdmitCardOpen, setIsPreviewAdmitCardOpen] = useState(false);
  const [previewStudent, setPreviewStudent] = useState<Student | null>(null);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Initial Data Fetching & Firebase connection check
  useEffect(() => {
    async function initData() {
      try {
        setIsLoadingData(true);
        // Test connection per Firebase skill directive
        await testConnection();

        const [fetchedStudents, fetchedExams, fetchedTimetables, fetchedSettings, fetchedLogs] =
          await Promise.all([
            dataService.getStudents(),
            dataService.getExams(),
            dataService.getTimetables(),
            dataService.getSchoolSettings(),
            dataService.getActivityLogs(),
          ]);

        if (fetchedStudents && fetchedStudents.length > 0) setStudents(fetchedStudents);
        if (fetchedExams && fetchedExams.length > 0) {
          setExams(fetchedExams);
          setActiveExamId(fetchedExams[0].id);
        }
        if (fetchedTimetables && fetchedTimetables.length > 0) setTimetables(fetchedTimetables);
        if (fetchedSettings) setSettings(fetchedSettings);
        if (fetchedLogs) setActivities(fetchedLogs);
      } catch (err) {
        console.error('Initialization error:', err);
      } finally {
        setIsLoadingData(false);
      }
    }

    if (currentUser || isDemoAdmin) {
      initData();
    }
  }, [currentUser, isDemoAdmin]);

  // If Auth is still loading
  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-amber-400" />
          <p className="text-sm font-semibold text-blue-200">Loading RSKIC Portal...</p>
        </div>
      </div>
    );
  }

  // Protected Route: Must be logged in or demo admin
  if (!currentUser && !isDemoAdmin) {
    return <LoginView />;
  }

  const activeExam = exams.find((e) => e.id === activeExamId) || exams[0] || DEFAULT_EXAM;

  // Handlers for Students
  const handleSaveStudent = async (student: Student) => {
    await dataService.saveStudent(student);
    setStudents((prev) => {
      const idx = prev.findIndex((s) => s.id === student.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = student;
        return copy;
      }
      return [...prev, student];
    });

    const isEdit = Boolean(studentToEdit);
    const actionText = isEdit
      ? `Updated student details for ${student.studentName}`
      : `Enrolled new student: ${student.studentName} (Class ${student.class}-${student.section})`;
    await dataService.logActivity(actionText, 'student', currentUser?.email || undefined);
    const updatedLogs = await dataService.getActivityLogs();
    setActivities(updatedLogs);
  };

  const handleDeleteStudent = async (studentId: string) => {
    const student = students.find((s) => s.id === studentId);
    await dataService.deleteStudent(studentId);
    setStudents((prev) => prev.filter((s) => s.id !== studentId));
    if (student) {
      await dataService.logActivity(
        `Removed student record: ${student.studentName}`,
        'student',
        currentUser?.email || undefined
      );
      const updatedLogs = await dataService.getActivityLogs();
      setActivities(updatedLogs);
    }
  };

  const handleImportExcelSuccess = async (importedStudents: Student[]) => {
    await dataService.bulkSaveStudents(importedStudents);
    setStudents((prev) => [...prev, ...importedStudents]);
    await dataService.logActivity(
      `Imported ${importedStudents.length} students via Excel spreadsheet`,
      'import',
      currentUser?.email || undefined
    );
    const updatedLogs = await dataService.getActivityLogs();
    setActivities(updatedLogs);
  };

  // Handlers for Exams
  const handleSaveExam = async (exam: Exam) => {
    await dataService.saveExam(exam);
    setExams((prev) => {
      const idx = prev.findIndex((e) => e.id === exam.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = exam;
        return copy;
      }
      return [...prev, exam];
    });
    setActiveExamId(exam.id);
    await dataService.logActivity(
      `Saved examination session: ${exam.examName}`,
      'exam',
      currentUser?.email || undefined
    );
    const updatedLogs = await dataService.getActivityLogs();
    setActivities(updatedLogs);
  };

  const handleDeleteExam = async (examId: string) => {
    await dataService.deleteExam(examId);
    setExams((prev) => prev.filter((e) => e.id !== examId));
  };

  // Handlers for Timetable
  const handleSaveTimetableEntry = async (entry: TimetableEntry) => {
    await dataService.saveTimetableEntry(entry);
    setTimetables((prev) => {
      const idx = prev.findIndex((t) => t.id === entry.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = entry;
        return copy;
      }
      return [...prev, entry];
    });
    await dataService.logActivity(
      `Updated schedule: Class ${entry.class} - ${entry.subject} (${entry.date})`,
      'timetable',
      currentUser?.email || undefined
    );
    const updatedLogs = await dataService.getActivityLogs();
    setActivities(updatedLogs);
  };

  const handleDeleteTimetableEntry = async (entryId: string) => {
    await dataService.deleteTimetableEntry(entryId);
    setTimetables((prev) => prev.filter((t) => t.id !== entryId));
  };

  // Handlers for School Settings
  const handleSaveSettings = async (newSettings: SchoolSettings) => {
    await dataService.saveSchoolSettings(newSettings);
    setSettings(newSettings);
    await dataService.logActivity(
      'Updated official school branding and instructions',
      'settings',
      currentUser?.email || undefined
    );
    const updatedLogs = await dataService.getActivityLogs();
    setActivities(updatedLogs);
  };

  // Quick Open Modal helpers
  const handleOpenAddStudent = () => {
    setStudentToEdit(null);
    setIsStudentFormOpen(true);
  };

  const handleOpenEditStudent = (student: Student) => {
    setStudentToEdit(student);
    setIsStudentFormOpen(true);
  };

  const handlePreviewAdmitCard = (student: Student) => {
    setPreviewStudent(student);
    setIsPreviewAdmitCardOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      {/* Top Header Navbar */}
      <Navbar
        settings={settings}
        activeExam={activeExam}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        onOpenGuide={() => setIsGuideOpen(true)}
        onOpenBulkAdmitCards={() => setIsBulkAdmitCardsOpen(true)}
      />

      {/* Main Container */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Navigation Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          isMobileOpen={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
          onOpenBulkAdmitCards={() => setIsBulkAdmitCardsOpen(true)}
          onOpenExcelImport={() => setIsExcelImportOpen(true)}
          onOpenGuide={() => setIsGuideOpen(true)}
        />

        {/* Dynamic Tab Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0">
          {isLoadingData ? (
            <div className="py-24 flex flex-col items-center justify-center text-slate-500">
              <Loader2 className="w-8 h-8 animate-spin text-blue-900 mb-2" />
              <p className="text-sm font-semibold">Synchronizing with Firestore Database...</p>
            </div>
          ) : (
            <>
              {currentTab === 'dashboard' && (
                <DashboardOverview
                  students={students}
                  exams={exams}
                  timetables={timetables}
                  activeExam={activeExam}
                  activities={activities}
                  onNavigate={setCurrentTab}
                  onAddStudent={handleOpenAddStudent}
                  onOpenExcelImport={() => setIsExcelImportOpen(true)}
                  onOpenBulkAdmitCards={() => setIsBulkAdmitCardsOpen(true)}
                />
              )}

              {currentTab === 'students' && (
                <StudentList
                  students={students}
                  onAddStudent={handleOpenAddStudent}
                  onEditStudent={handleOpenEditStudent}
                  onDeleteStudent={handleDeleteStudent}
                  onOpenExcelImport={() => setIsExcelImportOpen(true)}
                  onOpenBulkAdmitCards={() => setIsBulkAdmitCardsOpen(true)}
                  onPreviewAdmitCard={handlePreviewAdmitCard}
                />
              )}

              {currentTab === 'exams' && (
                <ExamManagement
                  exams={exams}
                  activeExamId={activeExamId}
                  onSelectActiveExam={setActiveExamId}
                  onSaveExam={handleSaveExam}
                  onDeleteExam={handleDeleteExam}
                />
              )}

              {currentTab === 'timetable' && (
                <TimetableManagement
                  timetables={timetables}
                  activeExamId={activeExamId}
                  onSaveEntry={handleSaveTimetableEntry}
                  onDeleteEntry={handleDeleteTimetableEntry}
                />
              )}

              {currentTab === 'settings' && (
                <SchoolSettingsView
                  settings={settings}
                  onSaveSettings={handleSaveSettings}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* MODALS */}
      {/* 1. Add / Edit Student Modal */}
      <StudentFormModal
        isOpen={isStudentFormOpen}
        onClose={() => setIsStudentFormOpen(false)}
        onSave={handleSaveStudent}
        studentToEdit={studentToEdit}
        suggestedAdmitCardNumber={dataService.generateNextAdmitCardNumber(students)}
      />

      {/* 2. Excel Bulk Import Modal */}
      <ExcelImportModal
        isOpen={isExcelImportOpen}
        onClose={() => setIsExcelImportOpen(false)}
        existingStudents={students}
        onImportSuccess={handleImportExcelSuccess}
        getNextAdmitCardNumber={dataService.generateNextAdmitCardNumber}
      />

      {/* 3. Single Admit Card Preview & Print Modal */}
      {previewStudent && (
        <AdmitCardPreviewModal
          isOpen={isPreviewAdmitCardOpen}
          onClose={() => setIsPreviewAdmitCardOpen(false)}
          student={previewStudent}
          exam={activeExam}
          timetables={timetables}
          settings={settings}
          onEditStudent={handleOpenEditStudent}
        />
      )}

      {/* 4. Bulk Admit Card Generator Modal */}
      <BulkAdmitCardModal
        isOpen={isBulkAdmitCardsOpen}
        onClose={() => setIsBulkAdmitCardsOpen(false)}
        students={students}
        exam={activeExam}
        timetables={timetables}
        settings={settings}
        onLogActivity={async (msg) => {
          await dataService.logActivity(msg, 'admit_card', currentUser?.email || undefined);
          const updatedLogs = await dataService.getActivityLogs();
          setActivities(updatedLogs);
        }}
      />

      {/* 5. 10-Step Administrator Guide Modal */}
      <InstructionsGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}
